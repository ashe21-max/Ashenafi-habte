package com.papantsh.onlineshop.dao;

import com.papantsh.onlineshop.DBHandler;
import com.papantsh.onlineshop.Product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductCrudDaoImpl implements ProductDao {

    @Override
    public List<Product> findAll() {
        List<Product> out = new ArrayList<>();
        String sql = "SELECT id, name, description, price, stock, category, image_path, created_at, coalesce(active,1) as active FROM products";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(new Product(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("stock"),
                        rs.getString("category"),
                        rs.getString("image_path"),
                        rs.getString("created_at"),
                        rs.getInt("active") == 1
                ));
            }
        } catch (SQLException e) {
            System.out.println("Product.findAll error: " + e.getMessage());
        }
        return out;
    }

    @Override
    public boolean create(Product p) {
        String sql = "INSERT INTO products (name, description, price, stock, category, image_path, created_at, active) VALUES (?, ?, ?, ?, ?, ?, COALESCE(?, datetime('now')), ?)";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getName());
            ps.setString(2, p.getDescription());
            ps.setDouble(3, p.getPrice());
            ps.setInt(4, p.getStock());
            ps.setString(5, p.getCategory());
            ps.setString(6, p.getImagePath());
            ps.setString(7, p.getCreatedAt());
            ps.setInt(8, p.isActive() ? 1 : 0);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Product.create error: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean update(Product p) {
        String sql = "UPDATE products SET name=?, description=?, price=?, stock=?, category=?, image_path=?, active=? WHERE id=?";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getName());
            ps.setString(2, p.getDescription());
            ps.setDouble(3, p.getPrice());
            ps.setInt(4, p.getStock());
            ps.setString(5, p.getCategory());
            ps.setString(6, p.getImagePath());
            ps.setInt(7, p.isActive() ? 1 : 0);
            ps.setInt(8, p.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Product.update error: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM products WHERE id = ?";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Product.delete error: " + e.getMessage());
            return false;
        }
    }

    @Override
    public Product findById(int id) {
        String sql = "SELECT id, name, description, price, stock, category, image_path, created_at, coalesce(active,1) as active FROM products WHERE id = ?";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                        return new Product(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("description"),
                            rs.getDouble("price"),
                            rs.getInt("stock"),
                            rs.getString("category"),
                            rs.getString("image_path"),
                                rs.getString("created_at"),
                                rs.getInt("active") == 1
                    );
                }
            }
        } catch (SQLException e) {
            System.out.println("Product.findById error: " + e.getMessage());
        }
        return null;
    }

    @Override
    public boolean setActive(int id, boolean active) {
        String sql = "UPDATE products SET active = ? WHERE id = ?";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, active ? 1 : 0);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Product.setActive error: " + e.getMessage());
            return false;
        }
    }
}
