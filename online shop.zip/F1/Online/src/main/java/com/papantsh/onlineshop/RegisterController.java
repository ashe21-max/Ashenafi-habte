package com.papantsh.onlineshop;

import javafx.animation.PauseTransition;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.util.Duration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterController {

    @FXML private TextField usernameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private Label statusLabel;

    @FXML
    private void onRegisterClick() {
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText().trim();
        String confirm = confirmPasswordField.getText().trim();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
            statusLabel.setText("Please fill all fields.");
            return;
        }

        if (!password.equals(confirm)) {
            statusLabel.setText("Passwords do not match.");
            return;
        }

        String hashed = DBHandler.hashPassword(password);

        String sql = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBHandler.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, email);
            ps.setString(3, hashed);
            ps.setString(4, "USER");
            ps.executeUpdate();

            statusLabel.setStyle("-fx-text-fill: green;");
            statusLabel.setText("Registration successful! Redirecting...");

            // Redirect to login after short delay using JavaFX PauseTransition
            PauseTransition delay = new PauseTransition(Duration.seconds(1));
            delay.setOnFinished(ev -> {
                SceneController sc = new SceneController(Main.mainStage);
                sc.switchTo("login.fxml");
            });
            delay.play();

        } catch (SQLException e) {
            e.printStackTrace();
            String msg = e.getMessage() == null ? "" : e.getMessage();
            if (msg.contains("UNIQUE constraint") || msg.contains("UNIQUE") || msg.toLowerCase().contains("unique")) {
                statusLabel.setText("Username or email already exists.");
            } else {
                statusLabel.setText("Error: " + e.getMessage());
            }
        }
    }

    @FXML
    private void onBackClick() {
        SceneController sc = new SceneController(Main.mainStage);
        sc.switchTo("login.fxml");
    }
}
