package com.papantsh.onlineshop;

import java.sql.*;
import org.mindrot.jbcrypt.BCrypt;

public class DBHandler {

    private static final String URL = "jdbc:sqlite:online_shop.db";

    public static String getDbFilePath() {
        if (URL != null && URL.startsWith("jdbc:sqlite:")) return URL.substring("jdbc:sqlite:".length());
        return URL;
    }

    // Connect to SQLite
    public static Connection connect() {
        try {
            return DriverManager.getConnection(URL);
        } catch (SQLException e) {
            System.out.println("DB Connection failed: " + e.getMessage());
            return null;
        }
    }

    // BCrypt password hashing
    public static String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt(12));
    }

    public static boolean verifyPassword(String plainPassword, String hashed) {
        if (hashed == null || hashed.isEmpty()) return false;
        return BCrypt.checkpw(plainPassword, hashed);
    }

    // Legacy SHA-256 fallback (used to upgrade old passwords)
    private static String sha256Hex(String password) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] hashed = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashed) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    // Create necessary tables
    public static void createTables() {
    String usersTable = """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'USER',
            created_at TEXT DEFAULT (datetime('now'))
        );
    """;

    String productsTable = """
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            category TEXT,
            stock INTEGER NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            image_path TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );
    """;
        String categoriesTable = """
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE
            );
        """;
    String cartTable = """
    CREATE TABLE IF NOT EXISTS cart (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL
    );
""";
String ordersTable = """
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        total_price REAL,
        order_date TEXT DEFAULT (datetime('now')),
        status TEXT NOT NULL DEFAULT 'PENDING'
    );
""";

String orderItemsTable = """
    CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        price REAL
    );
""";

try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
    stmt.execute(usersTable);
    stmt.execute(productsTable);
        stmt.execute(categoriesTable);
    stmt.execute(cartTable);
    stmt.execute(ordersTable);
    stmt.execute(orderItemsTable);
    System.out.println("All tables created successfully!");
} catch (SQLException e) {
    System.out.println("Error creating tables: " + e.getMessage());
}

        // Migration: if existing users table lacks new columns, add them
        try (Connection conn = connect()) {
            if (conn != null) {
                // gather existing columns
                java.util.Set<String> cols = new java.util.HashSet<>();
                try (java.sql.Statement s = conn.createStatement();
                     java.sql.ResultSet rs = s.executeQuery("PRAGMA table_info(users);")) {
                    while (rs.next()) cols.add(rs.getString("name").toLowerCase());
                }

                if (!cols.contains("email")) {
                    try (Statement s = conn.createStatement()) {
                        // SQLite cannot add UNIQUE constraint in ALTER TABLE ADD COLUMN; add plain column then a unique index
                        s.execute("ALTER TABLE users ADD COLUMN email TEXT;");
                        try {
                            s.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email);");
                        } catch (SQLException ix) {
                            System.out.println("Could not create unique index on email: " + ix.getMessage());
                        }
                        System.out.println("Added 'email' column to users table.");
                    } catch (SQLException ex) {
                        System.out.println("Could not add email column: " + ex.getMessage());
                    }
                }

                if (!cols.contains("role")) {
                    try (Statement s = conn.createStatement()) {
                        s.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'USER';");
                        System.out.println("Added 'role' column to users table.");
                    } catch (SQLException ex) {
                        System.out.println("Could not add role column: " + ex.getMessage());
                    }
                }

                if (!cols.contains("created_at")) {
                    try (Statement s = conn.createStatement()) {
                        // SQLite does not allow non-constant defaults in ALTER TABLE; add nullable column then backfill
                        s.execute("ALTER TABLE users ADD COLUMN created_at TEXT;");
                        s.execute("UPDATE users SET created_at = datetime('now') WHERE created_at IS NULL;");
                        System.out.println("Added 'created_at' column to users table and backfilled values.");
                    } catch (SQLException ex) {
                        System.out.println("Could not add created_at column: " + ex.getMessage());
                    }
                }

                if (!cols.contains("profile_image")) {
                    try (Statement s = conn.createStatement()) {
                        s.execute("ALTER TABLE users ADD COLUMN profile_image TEXT;");
                        s.execute("UPDATE users SET profile_image = NULL WHERE profile_image IS NULL;");
                        System.out.println("Added 'profile_image' column to users table.");
                    } catch (SQLException ex) {
                        System.out.println("Could not add profile_image column: " + ex.getMessage());
                    }
                }
                if (!cols.contains("phone")) {
                    try (Statement s = conn.createStatement()) {
                        s.execute("ALTER TABLE users ADD COLUMN phone TEXT;");
                        s.execute("UPDATE users SET phone = NULL WHERE phone IS NULL;");
                        System.out.println("Added 'phone' column to users table.");
                    } catch (SQLException ex) {
                        System.out.println("Could not add phone column: " + ex.getMessage());
                    }
                }
                if (!cols.contains("address")) {
                    try (Statement s = conn.createStatement()) {
                        s.execute("ALTER TABLE users ADD COLUMN address TEXT;");
                        s.execute("UPDATE users SET address = NULL WHERE address IS NULL;");
                        System.out.println("Added 'address' column to users table.");
                    } catch (SQLException ex) {
                        System.out.println("Could not add address column: " + ex.getMessage());
                    }
                }

                // add active column to users (soft-disable user accounts)
                if (!cols.contains("active")) {
                    try (Statement s2 = conn.createStatement()) {
                        s2.execute("ALTER TABLE users ADD COLUMN active INTEGER NOT NULL DEFAULT 1;");
                        s2.execute("UPDATE users SET active = 1 WHERE active IS NULL;");
                        System.out.println("Added 'active' column to users table and backfilled values.");
                    } catch (SQLException ex) {
                        System.out.println("Could not add active to users: " + ex.getMessage());
                    }
                }

                // Migration for products.created_at
                try (java.sql.Statement s = conn.createStatement();
                     java.sql.ResultSet rsProd = s.executeQuery("PRAGMA table_info(products);")) {
                    java.util.Set<String> prodCols = new java.util.HashSet<>();
                    while (rsProd.next()) prodCols.add(rsProd.getString("name").toLowerCase());
                    if (!prodCols.contains("created_at")) {
                        try (Statement s2 = conn.createStatement()) {
                            s2.execute("ALTER TABLE products ADD COLUMN created_at TEXT;");
                            s2.execute("UPDATE products SET created_at = datetime('now') WHERE created_at IS NULL;");
                            System.out.println("Added 'created_at' column to products table and backfilled values.");
                        } catch (SQLException ex) {
                            System.out.println("Could not add created_at to products: " + ex.getMessage());
                        }
                    }
                    // add active column if missing (soft-delete flag)
                    if (!prodCols.contains("active")) {
                        try (Statement s2 = conn.createStatement()) {
                            s2.execute("ALTER TABLE products ADD COLUMN active INTEGER NOT NULL DEFAULT 1;");
                            s2.execute("UPDATE products SET active = 1 WHERE active IS NULL;");
                            System.out.println("Added 'active' column to products table and backfilled values.");
                        } catch (SQLException ex) {
                            System.out.println("Could not add active to products: " + ex.getMessage());
                        }
                    }
                } catch (SQLException ex) {
                    System.out.println("Could not inspect products table: " + ex.getMessage());
                }

                // Ensure orders table has a status column (used for pending/completed)
                try (java.sql.Statement s = conn.createStatement();
                     java.sql.ResultSet rsOrders = s.executeQuery("PRAGMA table_info(orders);")) {
                    java.util.Set<String> orderCols = new java.util.HashSet<>();
                    while (rsOrders.next()) orderCols.add(rsOrders.getString("name").toLowerCase());
                    if (!orderCols.contains("status")) {
                        try (Statement s2 = conn.createStatement()) {
                            s2.execute("ALTER TABLE orders ADD COLUMN status TEXT NOT NULL DEFAULT 'PENDING';");
                            s2.execute("UPDATE orders SET status = 'PENDING' WHERE status IS NULL;");
                            System.out.println("Added 'status' column to orders table and backfilled values.");
                        } catch (SQLException ex) {
                            System.out.println("Could not add status column to orders: " + ex.getMessage());
                        }
                    }
                    // Add delivery fields if missing
                    if (!orderCols.contains("delivery_address")) {
                        try (Statement s2 = conn.createStatement()) {
                            s2.execute("ALTER TABLE orders ADD COLUMN delivery_address TEXT;");
                            System.out.println("Added 'delivery_address' column to orders table.");
                        } catch (SQLException ex) {
                            System.out.println("Could not add delivery_address to orders: " + ex.getMessage());
                        }
                    }
                    if (!orderCols.contains("delivery_phone")) {
                        try (Statement s2 = conn.createStatement()) {
                            s2.execute("ALTER TABLE orders ADD COLUMN delivery_phone TEXT;");
                            System.out.println("Added 'delivery_phone' column to orders table.");
                        } catch (SQLException ex) {
                            System.out.println("Could not add delivery_phone to orders: " + ex.getMessage());
                        }
                    }
                } catch (SQLException ex) {
                    System.out.println("Could not inspect orders table: " + ex.getMessage());
                }
            }
        } catch (SQLException e) {
            System.out.println("Migration check failed: " + e.getMessage());
        }


    
}


    // Check login credentials
    public static boolean validateLogin(String username, String password) {
        String sql = "SELECT password FROM users WHERE username = ?";

        try (Connection conn = connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (!rs.next()) return false; // username not found

            String storedHash = rs.getString("password");
            if (storedHash == null) return false;

            // If stored hash looks like bcrypt (starts with $2), verify using bcrypt
            if (storedHash.startsWith("$2")) {
                return verifyPassword(password, storedHash);
            }

            // Otherwise assume legacy SHA-256 hex digest: verify and upgrade to bcrypt
            String inputSha = sha256Hex(password);
            if (inputSha.equals(storedHash)) {
                // upgrade: compute bcrypt and update DB
                String newHash = hashPassword(password);
                try (PreparedStatement ups = conn.prepareStatement("UPDATE users SET password = ? WHERE username = ?")) {
                    ups.setString(1, newHash);
                    ups.setString(2, username);
                    ups.executeUpdate();
                } catch (SQLException ue) {
                    System.out.println("Failed to upgrade password hash: " + ue.getMessage());
                }
                return true;
            }

            return false;

        } catch (SQLException e) {
            System.out.println("Login validation error: " + e.getMessage());
            return false;
        }
    }

    // Fetch user by username (without password)
    public static User getUserByUsername(String username) {
        String sql = "SELECT id, username, email, role, COALESCE(active,1) as active, created_at, profile_image, phone, address FROM users WHERE username = ?";
        try (Connection conn = connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                        User u = new User(
                            rs.getInt("id"),
                            rs.getString("username"),
                            rs.getString("email"),
                            rs.getString("role"),
                            "" // don't expose password
                    );
                        try { u.setActive(rs.getInt("active") == 1); } catch (Exception ignored) {}
                        try { u.setCreatedAt(rs.getString("created_at")); } catch (Exception ignored) {}
                        try { u.setImagePath(rs.getString("profile_image")); } catch (Exception ignored) {}
                        try { u.setPhone(rs.getString("phone")); } catch (Exception ignored) {}
                        try { u.setAddress(rs.getString("address")); } catch (Exception ignored) {}
                        return u;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error fetching user: " + e.getMessage());
        }
        return null;
    }
}
