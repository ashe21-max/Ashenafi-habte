package com.papantsh.onlineshop.dao;

import com.papantsh.onlineshop.DBHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDaoImpl implements ProductRecentDao {

    @Override
    public List<ProductSummary> getRecentProducts(int limit) {
        List<ProductSummary> out = new ArrayList<>();
        String sql = "SELECT id, name, price, stock, image_path FROM products WHERE coalesce(active,1)=1 ORDER BY datetime(created_at) DESC LIMIT ?";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.add(new ProductSummary(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getDouble("price"),
                            rs.getInt("stock"),
                            rs.getString("image_path")
                    ));
                }
            }
        } catch (SQLException e) {
            System.out.println("getRecentProducts error: " + e.getMessage());
        }
        return out;
    }
}
