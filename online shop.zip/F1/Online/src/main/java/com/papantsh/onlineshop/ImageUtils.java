package com.papantsh.onlineshop;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ImageUtils {

    private ImageUtils() {}

    public static boolean createThumbnail(Path src, Path dest, int width, int height) {
        try {
            if (!Files.exists(src)) return false;
            if (!Files.exists(dest.getParent())) Files.createDirectories(dest.getParent());

            BufferedImage original = ImageIO.read(src.toFile());
            if (original == null) return false;

            int ow = original.getWidth();
            int oh = original.getHeight();

            double scale = Math.min((double)width / ow, (double)height / oh);
            int tw = Math.max(1, (int)Math.round(ow * scale));
            int th = Math.max(1, (int)Math.round(oh * scale));

            Image scaled = original.getScaledInstance(tw, th, Image.SCALE_SMOOTH);
            BufferedImage thumbnail = new BufferedImage(tw, th, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2 = thumbnail.createGraphics();
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g2.drawImage(scaled, 0, 0, null);
            g2.dispose();

            String outFormat = guessFormat(dest);
            return ImageIO.write(thumbnail, outFormat, dest.toFile());
        } catch (IOException e) {
            System.out.println("createThumbnail failed: " + e.getMessage());
            return false;
        }
    }

    private static String guessFormat(Path p) {
        String name = p.getFileName().toString().toLowerCase();
        if (name.endsWith(".png")) return "png";
        if (name.endsWith(".gif")) return "gif";
        return "jpg"; // default
    }
}
