package com.papantsh.onlineshop.dao;

import com.papantsh.onlineshop.DBHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoryDaoImpl implements CategoryDao {

    @Override
    public List<Category> findAll() {
        List<Category> out = new ArrayList<>();
        String sql = "SELECT id, name FROM categories ORDER BY name";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) out.add(new Category(rs.getInt("id"), rs.getString("name")));
        } catch (SQLException e) {
            System.out.println("findAll categories error: " + e.getMessage());
        }
        return out;
    }

    @Override
    public boolean create(String name) {
        String sql = "INSERT INTO categories(name) VALUES(?)";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, name);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("create category error: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean update(int id, String name) {
        String sql = "UPDATE categories SET name = ? WHERE id = ?";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("update category error: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM categories WHERE id = ?";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("delete category error: " + e.getMessage());
            return false;
        }
    }
}
