package com.papantsh.onlineshop;

import com.papantsh.onlineshop.dao.Order;
import com.papantsh.onlineshop.dao.OrderDaoImpl;
import com.papantsh.onlineshop.dao.OrderItem;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class OrdersController {

    @FXML private TableView<Order> tblOrders;
    @FXML private TableColumn<Order, Integer> colOrderId;
    @FXML private TableColumn<Order, String> colDate;
    @FXML private TableColumn<Order, String> colProducts;
    @FXML private TableColumn<Order, String> colStatus;
    @FXML private TableColumn<Order, Double> colTotal;
    @FXML private TableColumn<Order, Void> colActions;
    @FXML private Label lblInfo;

    // filter controls
    @FXML private TextField tfSearch;
    @FXML private ChoiceBox<String> cbStatus;
    @FXML private javafx.scene.control.DatePicker dpFrom;
    @FXML private javafx.scene.control.DatePicker dpTo;
    @FXML private Button btnFilter;
    @FXML private Button btnClear;

    private final OrderDaoImpl dao = new OrderDaoImpl();

    @FXML
    public void initialize() {
        if (colOrderId != null) colOrderId.setCellValueFactory(new PropertyValueFactory<>("id"));
        if (colDate != null) colDate.setCellValueFactory(new PropertyValueFactory<>("orderDate"));
        if (colProducts != null) colProducts.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getProducts()));
        if (colStatus != null) colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        if (colTotal != null) colTotal.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));

        // format date column
        if (colDate != null) {
            colDate.setCellFactory(c -> new TableCell<>() {
                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) { setText(null); return; }
                    try {
                        java.time.format.DateTimeFormatter source = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                        java.time.LocalDateTime dt = java.time.LocalDateTime.parse(item, source);
                        java.time.format.DateTimeFormatter out = java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm");
                        setText(dt.format(out));
                    } catch (Exception ex) {
                        setText(item);
                    }
                }
            });
        }

        // status badge styling
        if (colStatus != null) {
            colStatus.setCellFactory(c -> new TableCell<>() {
                private final Label lbl = new Label();
                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) { setGraphic(null); return; }
                    lbl.setText(item);
                    String color = switch (item.toUpperCase()) {
                        case "COMPLETED" -> "#2ecc71";
                        case "CANCELLED" -> "#e74c3c";
                        default -> "#f39c12"; // pending/or others
                    };
                    lbl.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; -fx-padding:4 8 4 8; -fx-background-radius:6;");
                    setGraphic(lbl);
                }
            });
        }

        // add actions column (View Details)
        if (colActions != null) {
            colActions.setCellFactory(col -> new TableCell<>() {
                private final Button btnView = new Button("View");

                {
                    btnView.setOnAction(e -> {
                        Order o = getTableView().getItems().get(getIndex());
                        showOrderDetails(o.getId());
                    });
                }

                @Override
                protected void updateItem(Void item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) setGraphic(null);
                    else setGraphic(btnView);
                }
            });
        }

        // wire filter controls
        if (cbStatus != null && cbStatus.getItems().isEmpty()) cbStatus.getItems().addAll("ALL","PENDING","COMPLETED","CANCELLED");
        if (btnFilter != null) btnFilter.setOnAction(e -> applyFilters());
        if (btnClear != null) btnClear.setOnAction(e -> {
            if (tfSearch != null) tfSearch.clear();
            if (cbStatus != null) cbStatus.setValue("ALL");
            if (dpFrom != null) dpFrom.setValue(null);
            if (dpTo != null) dpTo.setValue(null);
            loadOrdersForCurrentUser();
        });

        loadOrdersForCurrentUser();
    }

    private void loadOrdersForCurrentUser() {
        int userId = CurrentSession.getUserId();
        List<Order> orders;
        boolean isAdmin = "ADMIN".equalsIgnoreCase(CurrentSession.getRole());
        if (!isAdmin && userId > 0) orders = dao.getOrdersForUser(userId);
        else orders = dao.getAllOrders();

        ObservableList<Order> rows = FXCollections.observableArrayList(orders);
        if (tblOrders != null) tblOrders.setItems(rows);

        if (lblInfo != null) lblInfo.setText("Showing " + rows.size() + " orders");
    }

    private void showOrderDetails(int orderId) {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("/fxml/order_details.fxml"));
            javafx.scene.Parent root = loader.load();
            OrderDetailsController controller = loader.getController();
            controller.setOrder(orderId);

            javafx.stage.Stage st = new javafx.stage.Stage();
            st.setTitle("Order " + orderId);
            st.setScene(new javafx.scene.Scene(root));
            st.initOwner(Main.mainStage);
            st.show();
        } catch (Exception ex) {
            System.out.println("Unable to open order details: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void applyFilters() {
        String query = (tfSearch != null) ? tfSearch.getText() : null;
        String status = null;
        if (cbStatus != null && cbStatus.getValue() != null && !"ALL".equalsIgnoreCase(cbStatus.getValue())) status = cbStatus.getValue();
        String dateFrom = (dpFrom != null && dpFrom.getValue() != null) ? dpFrom.getValue().toString() : null;
        String dateTo = (dpTo != null && dpTo.getValue() != null) ? dpTo.getValue().toString() : null;

        List<Order> rows = dao.searchOrders(query, status, dateFrom, dateTo, null, null);
        ObservableList<Order> obs = FXCollections.observableArrayList(rows);
        if (tblOrders != null) tblOrders.setItems(obs);
        if (lblInfo != null) lblInfo.setText("Showing " + obs.size() + " orders");
    }

    // simple navigation handlers used by nav_buttons include
    @FXML
    private void onPrev() {
        new SceneController(Main.mainStage).switchTo("dashboard.fxml");
    }

    @FXML
    private void onNext() {
        new SceneController(Main.mainStage).switchTo("product_list.fxml");
    }
}
