package com.papantsh.onlineshop;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.IntegerStringConverter;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.sql.*;

public class CartController {

    @FXML private TableView<CartItem> tableCart;
    @FXML private TableColumn<CartItem, String> colImage;
    @FXML private TableColumn<CartItem, String> colProduct;
    @FXML private TableColumn<CartItem, Double> colPrice;
    @FXML private TableColumn<CartItem, Integer> colQuantity;
    @FXML private TableColumn<CartItem, Double> colTotal;
    @FXML private TableColumn<CartItem, Void> colRemove;

    @FXML private Button btnContinue;
    @FXML private Button btnCheckout;
    @FXML private Button btnSaveForLater;
    @FXML private Label statusLabel;
    @FXML private Label lblSubtotal;
    @FXML private Label lblTax;
    @FXML private Label lblTotalAmount;
    @FXML private TextField tfDeliveryAddress;
    @FXML private TextField tfDeliveryPhone;

    private ObservableList<CartItem> cartList = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        tableCart.setEditable(true);

        colImage.setCellFactory(col -> new TableCell<>() {
            private final ImageView iv = new ImageView();
            { iv.setFitWidth(80); iv.setFitHeight(60); iv.setPreserveRatio(true); }
            @Override
            protected void updateItem(String path, boolean empty) {
                super.updateItem(path, empty);
                if (empty || path == null || path.isBlank()) { setGraphic(null); }
                else { try { iv.setImage(new Image(new java.io.File(path).toURI().toString(), 80, 60, true, true)); setGraphic(iv); } catch (Exception ex) { setGraphic(null); } }
            }
        });

        colImage.setCellValueFactory(data -> data.getValue().imagePathProperty());
        colProduct.setCellValueFactory(data -> data.getValue().productNameProperty());
        colPrice.setCellValueFactory(data -> data.getValue().priceProperty().asObject());

        colQuantity.setCellValueFactory(data -> data.getValue().quantityProperty().asObject());
        colQuantity.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
        colQuantity.setOnEditCommit(ev -> {
            CartItem item = ev.getRowValue();
            int newQty = ev.getNewValue() <= 0 ? 1 : ev.getNewValue();
            item.setQuantity(newQty);
            try (Connection conn = DBHandler.connect(); PreparedStatement ps = conn.prepareStatement("UPDATE cart SET quantity = ? WHERE id = ?")) {
                ps.setInt(1, newQty); ps.setInt(2, item.getId()); ps.executeUpdate();
            } catch (SQLException ex) { statusLabel.setText("Error updating quantity: " + ex.getMessage()); }
            tableCart.refresh(); updateSummary();
        });

        colTotal.setCellValueFactory(data -> data.getValue().totalProperty().asObject());

        colRemove.setCellFactory(col -> new TableCell<>() {
            private final Button btn = new Button("✖");
            { btn.setOnAction(e -> { CartItem item = getTableView().getItems().get(getIndex()); removeItem(item); }); }
            @Override protected void updateItem(Void v, boolean empty) { super.updateItem(v, empty); setGraphic(empty ? null : btn); }
        });

        loadCart();

        btnContinue.setOnAction(e -> new SceneController(Main.mainStage).switchTo("product_list.fxml"));
        btnCheckout.setOnAction(e -> doCheckout());
        btnSaveForLater.setOnAction(e -> { statusLabel.setText("Save for later not implemented yet."); });
    }

    private void removeItem(CartItem selected) {
        if (selected == null) return;
        String sql = "DELETE FROM cart WHERE id=?";
        try (Connection conn = DBHandler.connect(); PreparedStatement ps = conn.prepareStatement(sql)) { ps.setInt(1, selected.getId()); ps.executeUpdate(); loadCart(); statusLabel.setStyle("-fx-text-fill: green;"); statusLabel.setText("Item removed successfully."); }
        catch (SQLException ex) { statusLabel.setText("Error: " + ex.getMessage()); }
    }

    private void doCheckout() {
        int userId = CurrentSession.getUserId(); if (userId <= 0) { statusLabel.setText("Please login to checkout."); return; }
        if (cartList.isEmpty()) { statusLabel.setText("Cart is empty."); return; }
        double totalPrice = cartList.stream().mapToDouble(CartItem::getTotal).sum();
        String orderSql = "INSERT INTO orders (user_id, total_price, order_date, delivery_address, delivery_phone) VALUES (?, ?, CURRENT_TIMESTAMP, ?, ?)";
        String orderItemSql = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBHandler.connect()) {
            conn.setAutoCommit(false);
            try (PreparedStatement psOrder = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS)) {
            psOrder.setInt(1, userId); psOrder.setDouble(2, totalPrice);
            String addr = (tfDeliveryAddress != null) ? tfDeliveryAddress.getText().trim() : null;
            String phone = (tfDeliveryPhone != null) ? tfDeliveryPhone.getText().trim() : null;
            psOrder.setString(3, addr);
            psOrder.setString(4, phone);
            psOrder.executeUpdate();
                try (ResultSet rs = psOrder.getGeneratedKeys()) {
                    if (!rs.next()) throw new SQLException("Failed to obtain order id");
                    int orderId = rs.getInt(1);
                    try (PreparedStatement psItem = conn.prepareStatement(orderItemSql)) {
                        for (CartItem item : cartList) { psItem.setInt(1, orderId); psItem.setInt(2, item.getProductId()); psItem.setInt(3, item.getQuantity()); psItem.setDouble(4, item.getPrice()); psItem.addBatch(); }
                        psItem.executeBatch();
                    }
                    try (PreparedStatement psClear = conn.prepareStatement("DELETE FROM cart WHERE user_id = ?")) { psClear.setInt(1, userId); psClear.executeUpdate(); }
                    conn.commit(); loadCart(); statusLabel.setStyle("-fx-text-fill: green;"); statusLabel.setText("Checkout successful! Order placed.");
                }
            } catch (SQLException ex) { conn.rollback(); throw ex; }
        } catch (SQLException ex) { statusLabel.setText("Checkout failed: " + ex.getMessage()); }
    }

    @FXML private void onPrev() { new SceneController(Main.mainStage).switchTo("dashboard.fxml"); }
    @FXML private void onNext() { new SceneController(Main.mainStage).switchTo("product_list.fxml"); }

    private void loadCart() {
        cartList.clear();
        String sql = "SELECT c.id, p.name, c.quantity, p.price, c.quantity * p.price AS total, p.id AS productId, p.image_path " +
                     "FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id=?";
        int userId = CurrentSession.getUserId();
        if (userId <= 0) { statusLabel.setText("Please login to view cart."); tableCart.setItems(cartList); updateSummary(); return; }
        try (Connection conn = DBHandler.connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) { CartItem item = new CartItem(rs.getInt("id"), rs.getInt("productId"), rs.getString("name"), rs.getInt("quantity"), rs.getDouble("price"), rs.getString("image_path")); cartList.add(item); }
                tableCart.setItems(cartList); updateSummary();
            }
        } catch (SQLException e) { statusLabel.setText("Error loading cart: " + e.getMessage()); }
    }

    private void updateSummary() {
        double subtotal = cartList.stream().mapToDouble(CartItem::getTotal).sum();
        double tax = subtotal * 0.15; double total = subtotal + tax;
        lblSubtotal.setText(String.format("%.2f Birr", subtotal)); lblTax.setText(String.format("%.2f Birr", tax)); lblTotalAmount.setText(String.format("%.2f Birr", total));
    }
}

