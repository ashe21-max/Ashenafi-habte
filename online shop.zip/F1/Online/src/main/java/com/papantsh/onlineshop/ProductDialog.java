package com.papantsh.onlineshop;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Optional;

public class ProductDialog {

    private Product product;

    public ProductDialog(Product product) {
        this.product = product;
    }

    public Product showAndWait() {
        Dialog<Product> dialog = new Dialog<>();
        dialog.setTitle(product == null ? "Add Product" : "Edit Product");

        ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(okButton, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(10); grid.setPadding(new Insets(20));

        TextField tfName = new TextField();
        tfName.setPromptText("Name");
        TextField tfDescription = new TextField();
        tfDescription.setPromptText("Description");
        TextField tfPrice = new TextField();
        tfPrice.setPromptText("Price");
        TextField tfStock = new TextField();
        tfStock.setPromptText("Stock");
        TextField tfCategory = new TextField();
        tfCategory.setPromptText("Category");

        TextField tfImage = new TextField();
        tfImage.setPromptText("Image path (optional)");
        tfImage.setEditable(false);
        Button btnBrowse = new Button("Browse...");
        HBox imageBox = new HBox(8, tfImage, btnBrowse);

        ImageView preview = new ImageView();
        preview.setFitWidth(160);
        preview.setFitHeight(120);
        preview.setPreserveRatio(true);

        if (product != null) {
            tfName.setText(product.getName());
            tfDescription.setText(product.getDescription());
            tfPrice.setText(String.valueOf(product.getPrice()));
            tfStock.setText(String.valueOf(product.getStock()));
            tfCategory.setText(product.getCategory());
            tfImage.setText(product.getImagePath());
            if (product.getImagePath() != null && !product.getImagePath().isBlank()) {
                try {
                    Image img = new Image(new File(product.getImagePath()).toURI().toString(), 160, 120, true, true);
                    preview.setImage(img);
                } catch (Exception ignored) {}
            }
        }

        btnBrowse.setOnAction(e -> {
            FileChooser fc = new FileChooser();
            fc.setTitle("Choose product image");
            fc.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif")
            );
            File chosen = fc.showOpenDialog(null);
            if (chosen != null) {
                String saved = copyImageToData(chosen);
                tfImage.setText(saved);
                try {
                    Image img = new Image(new File(saved).toURI().toString(), 160, 120, true, true);
                    preview.setImage(img);
                } catch (Exception ignored) {}
            }
        });

        grid.add(new Label("Name:"), 0, 0); grid.add(tfName, 1, 0);
        grid.add(new Label("Description:"), 0, 1); grid.add(tfDescription, 1, 1);
        grid.add(new Label("Price:"), 0, 2); grid.add(tfPrice, 1, 2);
        grid.add(new Label("Stock:"), 0, 3); grid.add(tfStock, 1, 3);
        grid.add(new Label("Category:"), 0, 4); grid.add(tfCategory, 1, 4);
        grid.add(new Label("Image:"), 0, 5); grid.add(imageBox, 1, 5);
        grid.add(preview, 1, 6);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == okButton) {
                try {
                    double price = Double.parseDouble(tfPrice.getText());
                    int stock = Integer.parseInt(tfStock.getText());
                    String name = tfName.getText().trim();
                    String desc = tfDescription.getText().trim();
                    if (name.isEmpty()) return null;
                    Product p = new Product(name, desc, price, stock);
                    p.setCategory(tfCategory.getText().trim());
                    p.setImagePath(tfImage.getText().trim());
                    return p;
                } catch (NumberFormatException e) {
                    return null;
                }
            }
            return null;
        });

        Optional<Product> result = dialog.showAndWait();
        return result.orElse(null);
    }

    private String copyImageToData(File src) {
        try {
            Path imagesDir = Paths.get("data", "images");
            Path thumbsDir = imagesDir.resolve("thumbs");
            if (!Files.exists(imagesDir)) Files.createDirectories(imagesDir);
            if (!Files.exists(thumbsDir)) Files.createDirectories(thumbsDir);
            String name = src.getName();
            String ext = "";
            int dot = name.lastIndexOf('.');
            if (dot > 0) ext = name.substring(dot);
            String filename = System.currentTimeMillis() + ext;
            Path dest = imagesDir.resolve(filename);
            Files.copy(src.toPath(), dest, StandardCopyOption.REPLACE_EXISTING);

            // create thumbnail -> data/images/thumbs/<filename>
            Path thumb = thumbsDir.resolve(filename);
            ImageUtils.createThumbnail(dest, thumb, 200, 160);

            // return relative path (portable)
            return Paths.get("data", "images", filename).toString();
        } catch (IOException e) {
            System.out.println("Image copy failed: " + e.getMessage());
            return src.getAbsolutePath();
        }
    }
}
