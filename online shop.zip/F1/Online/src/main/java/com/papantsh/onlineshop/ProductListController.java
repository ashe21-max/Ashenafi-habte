package com.papantsh.onlineshop;

import com.papantsh.onlineshop.dao.CategoryDaoImpl;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductListController {

    @FXML private TextField tfSearch;
    @FXML private ComboBox<String> cbCategory;
    @FXML private TextField tfMinPrice;
    @FXML private TextField tfMaxPrice;
    @FXML private ComboBox<String> cbSort;
    @FXML private Button btnFilter;
    @FXML private Button btnClear;
    @FXML private FlowPane flowProducts;
    @FXML private Button btnPrev;
    @FXML private Button btnNext;
    @FXML private Button btnBack;
    @FXML private Label lblPageInfo;
    @FXML private Label statusLabel;

    private int page = 1;
    private final int pageSize = 12;

    // Product DAO (optional) - left for future use

    @FXML
    private void initialize() {
        // populate categories
        cbCategory.getItems().add("All");
        for (com.papantsh.onlineshop.dao.Category c : new CategoryDaoImpl().findAll()) cbCategory.getItems().add(c.getName());
        cbCategory.getSelectionModel().select("All");

        cbSort.getItems().addAll("Newest", "Price: Low → High", "Price: High → Low");
        cbSort.getSelectionModel().select("Newest");

        btnFilter.setOnAction(e -> { page = 1; loadProducts(); });
        btnClear.setOnAction(e -> { tfSearch.clear(); cbCategory.getSelectionModel().select("All"); tfMinPrice.clear(); tfMaxPrice.clear(); cbSort.getSelectionModel().select("Newest"); page = 1; loadProducts(); });

        btnPrev.setOnAction(e -> { if (page > 1) { page--; loadProducts(); } });
        btnNext.setOnAction(e -> { page++; loadProducts(); });

        btnBack.setOnAction(e -> new SceneController(Main.mainStage).switchTo("dashboard.fxml"));

        loadProducts();
    }

    private void loadProducts() {
        flowProducts.getChildren().clear();

        String q = tfSearch.getText();
        String cat = cbCategory.getSelectionModel().getSelectedItem();
        if (cat != null && (cat.equals("All") || cat.isBlank())) cat = null;
        Double min = parseDoubleSafe(tfMinPrice.getText());
        Double max = parseDoubleSafe(tfMaxPrice.getText());
        String sort = cbSort.getSelectionModel().getSelectedItem();

        StringBuilder sb = new StringBuilder("SELECT * FROM products WHERE coalesce(active,1)=1");
        List<Object> params = new ArrayList<>();
        if (q != null && !q.isBlank()) {
            sb.append(" AND (name LIKE ? OR description LIKE ?)");
            String like = "%" + q + "%";
            params.add(like); params.add(like);
        }
        if (cat != null && !cat.isBlank()) { sb.append(" AND category = ?"); params.add(cat); }
        if (min != null) { sb.append(" AND price >= ?"); params.add(min); }
        if (max != null) { sb.append(" AND price <= ?"); params.add(max); }

        // sorting
        if ("Price: Low → High".equals(sort)) sb.append(" ORDER BY price ASC");
        else if ("Price: High → Low".equals(sort)) sb.append(" ORDER BY price DESC");
        else sb.append(" ORDER BY datetime(created_at) DESC");

        // pagination
        sb.append(" LIMIT ? OFFSET ?");

        try (Connection conn = DBHandler.connect(); PreparedStatement ps = conn.prepareStatement(sb.toString())) {
            int idx = 1;
            for (Object p : params) { ps.setObject(idx++, p); }
            ps.setInt(idx++, pageSize);
            ps.setInt(idx++, (page - 1) * pageSize);

            try (ResultSet rs = ps.executeQuery()) {
                int count = 0;
                while (rs.next()) {
                    Product p = new Product(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("description"),
                            rs.getDouble("price"),
                            rs.getInt("stock"),
                            rs.getString("category"),
                            rs.getString("image_path"),
                            rs.getString("created_at"),
                            rs.getInt("active") == 1
                    );
                    flowProducts.getChildren().add(makeProductCard(p));
                    count++;
                }
                lblPageInfo.setText("Page " + page + (count < pageSize ? " (end)" : ""));
                if (count == 0 && page > 1) { page = Math.max(1, page - 1); loadProducts(); return; }
            }
        } catch (SQLException ex) {
            statusLabel.setText("Error loading products: " + ex.getMessage());
        }
    }

    private VBox makeProductCard(Product p) {
        VBox card = new VBox(6);
        card.setPrefWidth(200);
        card.setStyle("-fx-background-color: white; -fx-padding:8; -fx-effect: dropshadow(two-pass-box, rgba(0,0,0,0.04), 4,0,0,1);");

        ImageView iv = new ImageView(); iv.setFitWidth(180); iv.setFitHeight(120); iv.setPreserveRatio(true);
        try { if (p.getImagePath() != null && !p.getImagePath().isBlank()) iv.setImage(new Image(new java.io.File(p.getImagePath()).toURI().toString(), 180, 120, true, true)); } catch (Exception ignore) {}

        Label name = new Label(p.getName()); name.setWrapText(true); name.setStyle("-fx-font-weight:bold;");
        Label price = new Label(String.format("%.2f Birr", p.getPrice()));
        Label desc = new Label(p.getDescription() == null ? "" : (p.getDescription().length() > 80 ? p.getDescription().substring(0, 80) + "..." : p.getDescription())); desc.setWrapText(true);

        HBox actions = new HBox(8);
        Button btnView = new Button("View Details");
        btnView.setOnAction(e -> {
            try {
                javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("/fxml/product_details.fxml"));
                javafx.scene.Parent root = loader.load();
                ProductDetailsController controller = loader.getController();
                controller.setProduct(p);
                javafx.stage.Stage st = new javafx.stage.Stage();
                st.setTitle(p.getName());
                st.setScene(new javafx.scene.Scene(root));
                st.initOwner(Main.mainStage);
                st.show();
            } catch (Exception ex) { statusLabel.setText("Unable to open details: " + ex.getMessage()); }
        });

        Button btnAdd = new Button("Add to Cart");
        btnAdd.setOnAction(e -> {
            if (p.getStock() <= 0) { statusLabel.setText("Product out of stock."); return; }
            int userId = CurrentSession.getUserId();
            if (userId <= 0) { statusLabel.setText("Please login to add items to cart."); return; }
            String insertSql = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)";
            try (Connection conn = DBHandler.connect(); PreparedStatement ps = conn.prepareStatement(insertSql)) {
                ps.setInt(1, userId); ps.setInt(2, p.getId()); ps.setInt(3, 1); ps.executeUpdate();
                statusLabel.setStyle("-fx-text-fill: green;"); statusLabel.setText("Added to cart.");
            } catch (SQLException ex) { statusLabel.setText("Error: " + ex.getMessage()); }
        });

        actions.getChildren().addAll(btnView, btnAdd);

        card.getChildren().addAll(iv, name, price, desc, actions);
        return card;
    }

    private Double parseDoubleSafe(String s) {
        try { if (s == null || s.isBlank()) return null; return Double.parseDouble(s.trim()); } catch (Exception e) { return null; }
    }

    @FXML
    private void onPrev() {
        new SceneController(Main.mainStage).switchTo("dashboard.fxml");
    }

    @FXML
    private void onNext() {
        // navigate to shop (self)
        new SceneController(Main.mainStage).switchTo("product_list.fxml");
    }
}
