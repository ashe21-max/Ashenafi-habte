package com.papantsh.onlineshop;

import com.papantsh.onlineshop.dao.OrderItem;
import com.papantsh.onlineshop.dao.OrderDaoImpl;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OrderDetailsController {

    @FXML private Label lblTitle;
    @FXML private Label lblOrderId;
    @FXML private Label lblDate;
    @FXML private Label lblStatus;
    @FXML private Label lblDelivery;
    @FXML private TableView<OrderItem> tblItems;
    @FXML private TableColumn<OrderItem, String> colProd;
    @FXML private TableColumn<OrderItem, Integer> colQty;
    @FXML private TableColumn<OrderItem, Double> colPrice;
    @FXML private TableColumn<OrderItem, Double> colLineTotal;
    @FXML private Label lblTotal;
    @FXML private Button btnCancel;
    @FXML private Button btnReorder;

    private final OrderDaoImpl dao = new OrderDaoImpl();
    private int orderId = -1;

    @FXML
    public void initialize() {
        if (colProd != null) colProd.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getProductName()));
        if (colQty != null) colQty.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getQuantity()).asObject());
        if (colPrice != null) colPrice.setCellValueFactory(data -> new javafx.beans.property.SimpleDoubleProperty(data.getValue().getPrice()).asObject());
        if (colLineTotal != null) colLineTotal.setCellValueFactory(data -> new javafx.beans.property.SimpleDoubleProperty(data.getValue().getPrice() * data.getValue().getQuantity()).asObject());

        if (btnCancel != null) btnCancel.setOnAction(e -> cancelOrder());
        if (btnReorder != null) btnReorder.setOnAction(e -> reorderItems());
    }

    public void setOrder(int id) {
        this.orderId = id;
        loadOrder();
    }

    private void loadOrder() {
        try (Connection conn = DBHandler.connect();
             PreparedStatement ps = conn.prepareStatement("SELECT id, user_id, total_price, order_date, COALESCE(status,'PENDING') AS status, delivery_address, delivery_phone FROM orders WHERE id = ?")) {
            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    lblTitle.setText("Order Details");
                    lblOrderId.setText(String.valueOf(rs.getInt("id")));
                    lblDate.setText(rs.getString("order_date"));
                    lblStatus.setText(rs.getString("status"));
                    lblTotal.setText(String.format("$%.2f", rs.getDouble("total_price")));
                    String addr = rs.getString("delivery_address");
                    String phone = rs.getString("delivery_phone");
                    String delivery = (addr == null ? "" : addr) + (phone == null ? "" : (addr == null || addr.isEmpty() ? "" : " — ") + phone);
                    if (lblDelivery != null) lblDelivery.setText(delivery.isBlank() ? "(Not provided)" : delivery);
                    boolean canCancel = "PENDING".equalsIgnoreCase(rs.getString("status"));
                    btnCancel.setDisable(!canCancel);
                }
            }
        } catch (SQLException ex) {
            System.out.println("Error loading order: " + ex.getMessage());
        }

        // load items
        java.util.List<OrderItem> items = dao.getOrderItems(orderId);
        ObservableList<OrderItem> rows = FXCollections.observableArrayList(items);
        if (tblItems != null) tblItems.setItems(rows);
    }

    private void cancelOrder() {
        if (orderId <= 0) return;
        if (!com.papantsh.onlineshop.ui.DialogUtil.confirm("Cancel order", "Are you sure you want to cancel this order?")) return;
        boolean ok = dao.updateOrderStatus(orderId, "CANCELLED");
        if (ok) {
            lblStatus.setText("CANCELLED");
            btnCancel.setDisable(true);
        } else {
            com.papantsh.onlineshop.ui.DialogUtil.showError("Unable to cancel order.");
        }
    }

    private void reorderItems() {
        if (orderId <= 0) return;
        java.util.List<OrderItem> items = dao.getOrderItems(orderId);
        try (Connection conn = DBHandler.connect()) {
            conn.setAutoCommit(false);
            try (PreparedStatement psCheck = conn.prepareStatement("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?");
                 PreparedStatement psUpdate = conn.prepareStatement("UPDATE cart SET quantity = ? WHERE id = ?");
                 PreparedStatement psInsert = conn.prepareStatement("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");) {

                int userId = CurrentSession.getUserId();
                for (OrderItem it : items) {
                    // check exists
                    psCheck.setInt(1, userId);
                    psCheck.setInt(2, it.getProductId());
                    try (ResultSet rs = psCheck.executeQuery()) {
                        if (rs.next()) {
                            int existingId = rs.getInt("id");
                            int existingQty = rs.getInt("quantity");
                            psUpdate.setInt(1, existingQty + it.getQuantity());
                            psUpdate.setInt(2, existingId);
                            psUpdate.executeUpdate();
                        } else {
                            psInsert.setInt(1, userId);
                            psInsert.setInt(2, it.getProductId());
                            psInsert.setInt(3, it.getQuantity());
                            psInsert.executeUpdate();
                        }
                    }
                }
                conn.commit();
                com.papantsh.onlineshop.ui.DialogUtil.showInfo("Items added to cart.");
            } catch (SQLException ex) {
                conn.rollback();
                System.out.println("Reorder failed: " + ex.getMessage());
                com.papantsh.onlineshop.ui.DialogUtil.showError("Unable to add items to cart: " + ex.getMessage());
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException ex) {
            System.out.println("Reorder DB error: " + ex.getMessage());
        }
    }

    @FXML
    private void onClose() {
        // close the window
        javafx.stage.Stage st = (javafx.stage.Stage) lblTitle.getScene().getWindow();
        st.close();
    }
}
