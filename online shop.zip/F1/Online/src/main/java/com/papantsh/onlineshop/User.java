package com.papantsh.onlineshop;

import javafx.beans.property.*;

public class User {
    private final IntegerProperty id;
    private final StringProperty username;
    private final StringProperty email;
    private final StringProperty role;
    private final StringProperty password;
    private final BooleanProperty active;
    private final StringProperty createdAt;
    private final StringProperty imagePath;
    private final StringProperty phone;
    private final StringProperty address;

    public User(int id, String username, String email, String role, String password) {
        this.id = new SimpleIntegerProperty(id);
        this.username = new SimpleStringProperty(username);
        this.email = new SimpleStringProperty(email);
        this.role = new SimpleStringProperty(role);
        this.password = new SimpleStringProperty(password);
        this.active = new SimpleBooleanProperty(true);
        this.createdAt = new SimpleStringProperty("");
        this.imagePath = new SimpleStringProperty("");
        this.phone = new SimpleStringProperty("");
        this.address = new SimpleStringProperty("");
    }

    public StringProperty imagePathProperty() { return imagePath; }
    public String getImagePath() { return imagePath.get(); }
    public void setImagePath(String p) { this.imagePath.set(p); }

    public String getPhone() { return phone.get(); }
    public void setPhone(String p) { this.phone.set(p); }
    public StringProperty phoneProperty() { return phone; }

    public String getAddress() { return address.get(); }
    public void setAddress(String a) { this.address.set(a); }
    public StringProperty addressProperty() { return address; }

    public BooleanProperty activeProperty() { return active; }
    public StringProperty createdAtProperty() { return createdAt; }

    public boolean isActive() { return active.get(); }
    public void setActive(boolean val) { this.active.set(val); }

    public String getCreatedAt() { return createdAt.get(); }
    public void setCreatedAt(String v) { this.createdAt.set(v); }

    public int getId() { return id.get(); }
    public String getUsername() { return username.get(); }
    public String getEmail() { return email.get(); }
    public String getRole() { return role.get(); }
    public String getPassword() { return password.get(); }

    public IntegerProperty idProperty() { return id; }
    public StringProperty usernameProperty() { return username; }
    public StringProperty emailProperty() { return email; }
    public StringProperty roleProperty() { return role; }
    public StringProperty passwordProperty() { return password; }
}
