package com.papantsh.onlineshop;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class DashboardController {

    @FXML private javafx.scene.control.Button btnHome;
    @FXML private javafx.scene.control.Button btnShop;
    @FXML private javafx.scene.control.Button btnCart;
    @FXML private javafx.scene.control.Button btnOrders;
    @FXML private javafx.scene.control.Button btnProfile;
    @FXML private javafx.scene.control.Button btnLogout;
    @FXML private Label lblMain;
    @FXML private javafx.scene.layout.HBox topbar;

    @FXML
    private void initialize() {
        // wire navigation buttons
        if (btnHome != null) btnHome.setOnAction(e -> switchPage("user_home.fxml"));
        if (btnShop != null) btnShop.setOnAction(e -> switchPage("product_list.fxml"));
        if (btnCart != null) btnCart.setOnAction(e -> switchPage("cart.fxml"));
        if (btnOrders != null) btnOrders.setOnAction(e -> switchPage("orders.fxml"));
        if (btnProfile != null) btnProfile.setOnAction(e -> switchPage("user_profile.fxml"));
        if (btnLogout != null) btnLogout.setOnAction(e -> {
            boolean confirm = com.papantsh.onlineshop.ui.DialogUtil.confirmBlocking("Logout", "Are you sure you want to logout?");
            if (confirm) {
                CurrentSession.clear();
                new SceneController(Main.mainStage).switchTo("login.fxml");
            }
        });
        
        // show current user info if available
        Label lblUserInfo = null;
        if (topbar != null) {
            lblUserInfo = (Label) topbar.lookup("#lblUserInfo");
        }

        if (lblUserInfo != null) {
            if (CurrentSession.getUserId() > 0) {
                String role = CurrentSession.getRole() == null ? "" : " (" + CurrentSession.getRole() + ")";
                lblUserInfo.setText(CurrentSession.getUsername() + role);
            } else {
                lblUserInfo.setText("Not logged in");
            }
            // set avatar image (if available) and wire profile button
            try {
                javafx.scene.image.ImageView avatar = (javafx.scene.image.ImageView) topbar.lookup("#imgAvatar");
                if (avatar != null && CurrentSession.getUserId() > 0) {
                    try {
                        User u = DBHandler.getUserByUsername(CurrentSession.getUsername());
                        if (u != null && u.getImagePath() != null && !u.getImagePath().isBlank()) {
                            avatar.setImage(new javafx.scene.image.Image(new java.io.File(u.getImagePath()).toURI().toString()));
                        }
                    } catch (Exception ignore) {}
                }
            } catch (Exception ignore) {}
            javafx.scene.control.Button btnProfile = (javafx.scene.control.Button) topbar.lookup("#btnProfile");
            if (btnProfile != null) btnProfile.setOnAction(e -> switchPage("user_settings.fxml"));
        }

        // topbar logout removed (use sidebar logout)
    }
    private void switchPage(String fxml) {
        SceneController sc = new SceneController(Main.mainStage);
        sc.switchTo(fxml);
    }

    // explicit handlers used by FXML onAction attributes
    @FXML
    private void onShopClick() {
        switchPage("product_list.fxml");
    }

    @FXML
    private void onHomeClick() {
        switchPage("user_home.fxml");
    }

    @FXML
    private void onCartClick() {
        switchPage("cart.fxml");
    }

    @FXML
    private void onOrdersClick() {
        switchPage("orders.fxml");
    }

    @FXML
    private void onProfileClick() {
        switchPage("user_profile.fxml");
    }
    
}
