package com.papantsh.onlineshop.dao;

import java.util.List;

public interface CategoryDao {
    List<Category> findAll();
    boolean create(String name);
    boolean update(int id, String name);
    boolean delete(int id);
}
