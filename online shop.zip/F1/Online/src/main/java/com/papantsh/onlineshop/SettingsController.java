package com.papantsh.onlineshop;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.awt.Desktop;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class SettingsController {

    @FXML private PasswordField pfCurrent;
    @FXML private PasswordField pfNew;
    @FXML private PasswordField pfConfirm;
    @FXML private Button btnChangePassword;
    @FXML private Label lblPassStatus;

    @FXML private Label lblDbPath;
    @FXML private Button btnBackup;
    @FXML private Button btnExportCsv;
    @FXML private Label lblExportStatus;

    @FXML private javafx.scene.image.ImageView imgProfileSmall;
    @FXML private Button btnUploadProfile;
    @FXML private Label lblProfileUploadStatus;

    @FXML private ComboBox<Integer> cbLines;
    @FXML private Button btnReloadLogs;
    @FXML private Button btnClearLogs;
    @FXML private TextArea txtLogs;

    @FXML private Button btnMigrate;
    @FXML private Button btnOpenBackups;

    public void initialize() {
        lblDbPath.setText(DBHandler.getDbFilePath());

        cbLines.getItems().addAll(10, 50, 100, 500);
        cbLines.getSelectionModel().select(Integer.valueOf(50));

        LogUtil.ensureLogFile();
        loadLogs();

        btnReloadLogs.setOnAction(e -> loadLogs());
        btnClearLogs.setOnAction(e -> {
            if (com.papantsh.onlineshop.ui.DialogUtil.confirm("Clear logs", "Clear all logs?")) {
                LogUtil.clear();
                LogUtil.log("INFO", "Logs cleared by admin.");
                loadLogs();
            }
        });

        // profile upload for logged in user
        try {
            if (CurrentSession.getUserId() > 0) {
                User u = DBHandler.getUserByUsername(CurrentSession.getUsername());
                if (u != null && u.getImagePath() != null && !u.getImagePath().isBlank()) {
                    try { imgProfileSmall.setImage(new javafx.scene.image.Image(new java.io.File(u.getImagePath()).toURI().toString())); } catch (Exception ignore) {}
                }
                btnUploadProfile.setOnAction(ev -> {
                    javafx.stage.FileChooser fc = new javafx.stage.FileChooser();
                    fc.getExtensionFilters().add(new javafx.stage.FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.jpeg", "*.gif"));
                    java.io.File f = fc.showOpenDialog(Main.mainStage);
                    if (f == null) return;
                    try {
                        java.nio.file.Path destDir = java.nio.file.Paths.get("data", "profile_images");
                        java.nio.file.Files.createDirectories(destDir);
                        String name = System.currentTimeMillis() + "_" + f.getName();
                        java.nio.file.Path dest = destDir.resolve(name);
                        java.nio.file.Files.copy(f.toPath(), dest, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                        try (java.sql.Connection conn = DBHandler.connect(); java.sql.PreparedStatement ps = conn.prepareStatement("UPDATE users SET profile_image = ? WHERE id = ?")) {
                            ps.setString(1, dest.toString());
                            ps.setInt(2, CurrentSession.getUserId());
                            ps.executeUpdate();
                        }
                        imgProfileSmall.setImage(new javafx.scene.image.Image(dest.toFile().toURI().toString()));
                        lblProfileUploadStatus.setText("Profile image uploaded.");
                    } catch (Exception ex) {
                        lblProfileUploadStatus.setText("Upload failed: " + ex.getMessage());
                    }
                });
            } else {
                btnUploadProfile.setDisable(true);
            }
        } catch (Exception ignore) {}

        btnBackup.setOnAction(e -> doBackup());
        btnExportCsv.setOnAction(e -> doExportCsv());

        btnChangePassword.setOnAction(e -> doChangePassword());

        btnMigrate.setOnAction(e -> {
            DBHandler.createTables();
            lblExportStatus.setText("Migrations re-run (see console).");
            LogUtil.log("INFO", "Admin triggered DB migrations.");
        });

        btnOpenBackups.setOnAction(e -> {
            try {
                Path dir = Paths.get("data", "backups");
                if (!Files.exists(dir)) Files.createDirectories(dir);
                Desktop.getDesktop().open(dir.toFile());
            } catch (Exception ex) {
                lblExportStatus.setText("Unable to open backups folder: " + ex.getMessage());
            }
        });
    }

    private void loadLogs() {
        int lines = cbLines.getValue() == null ? 50 : cbLines.getValue();
        List<String> recent = LogUtil.tail(lines);
        txtLogs.clear();
        recent.forEach(l -> txtLogs.appendText(l + System.lineSeparator()));
    }

    private void doBackup() {
        try {
            Path db = Paths.get(DBHandler.getDbFilePath());
            Path backups = Paths.get("data", "backups");
            if (!Files.exists(backups)) Files.createDirectories(backups);
            String name = "online_shop-" + System.currentTimeMillis() + ".db";
            Path dest = backups.resolve(name);
            Files.copy(db, dest, StandardCopyOption.REPLACE_EXISTING);
            lblExportStatus.setText("Backup created: " + dest.toString());
            LogUtil.log("INFO", "DB backup created: " + dest);
        } catch (Exception ex) {
            lblExportStatus.setText("Backup failed: " + ex.getMessage());
            LogUtil.log("ERROR", "DB backup failed: " + ex.getMessage());
        }
    }

    private void doExportCsv() {
        // export products, users, orders, order_items
        Path out = Paths.get("data", "exports", String.valueOf(System.currentTimeMillis()));
        try {
            Files.createDirectories(out);
            try (Connection c = DBHandler.connect(); Statement s = c.createStatement()) {
                exportQueryToCsv(s, "SELECT id,name,description,price,category,stock,image_path,created_at FROM products", out.resolve("products.csv"));
                exportQueryToCsv(s, "SELECT id,username,email,role,created_at,active FROM users", out.resolve("users.csv"));
                exportQueryToCsv(s, "SELECT id,user_id,total_price,order_date,status FROM orders", out.resolve("orders.csv"));
                exportQueryToCsv(s, "SELECT id,order_id,product_id,quantity,price FROM order_items", out.resolve("order_items.csv"));
            }
            lblExportStatus.setText("Exported CSVs to: " + out.toString());
            LogUtil.log("INFO", "Exported CSVs to " + out.toString());
        } catch (Exception ex) {
            lblExportStatus.setText("Export failed: " + ex.getMessage());
            LogUtil.log("ERROR", "CSV export failed: " + ex.getMessage());
        }
    }

    private void exportQueryToCsv(Statement s, String sql, Path outFile) throws Exception {
        try (ResultSet rs = s.executeQuery(sql); BufferedWriter bw = Files.newBufferedWriter(outFile)) {
            int cols = rs.getMetaData().getColumnCount();
            // header
            for (int i = 1; i <= cols; i++) {
                if (i > 1) bw.write(',');
                bw.write(rs.getMetaData().getColumnName(i));
            }
            bw.newLine();
            while (rs.next()) {
                for (int i = 1; i <= cols; i++) {
                    if (i > 1) bw.write(',');
                    String val = rs.getString(i);
                    if (val != null) {
                        bw.write('"');
                        bw.write(val.replace("\"", "\"\"").replace(System.lineSeparator(), " "));
                        bw.write('"');
                    }
                }
                bw.newLine();
            }
        }
    }

    private void doChangePassword() {
        String current = pfCurrent.getText();
        String p1 = pfNew.getText();
        String p2 = pfConfirm.getText();
        if (current == null || current.isBlank() || p1 == null || p1.isBlank() || p2 == null || p2.isBlank()) {
            lblPassStatus.setText("Please fill all fields.");
            return;
        }
        if (!p1.equals(p2)) { lblPassStatus.setText("New passwords do not match."); return; }
        int uid = CurrentSession.getUserId();
        if (uid <= 0) { lblPassStatus.setText("You must be logged in as admin to change password."); return; }

        // verify current password
        String username = CurrentSession.getUsername();
        if (!DBHandler.validateLogin(username, current)) { lblPassStatus.setText("Current password incorrect."); return; }

        String sql = "UPDATE users SET password = ? WHERE id = ?";
        try (Connection conn = DBHandler.connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, DBHandler.hashPassword(p1));
            ps.setInt(2, uid);
            ps.executeUpdate();
            lblPassStatus.setText("Password changed successfully.");
            LogUtil.log("INFO", "Admin changed password for user " + username);
            // clear fields
            pfCurrent.clear(); pfNew.clear(); pfConfirm.clear();
        } catch (Exception ex) {
            lblPassStatus.setText("Failed: " + ex.getMessage());
            LogUtil.log("ERROR", "Failed change password: " + ex.getMessage());
        }
    }

    @FXML
    private void onPrev() {
        new SceneController(Main.mainStage).switchTo("dashboard.fxml");
    }

    @FXML
    private void onNext() {
        new SceneController(Main.mainStage).switchTo("product_list.fxml");
    }
}
