package com.papantsh.onlineshop.dao;

import com.papantsh.onlineshop.DBHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StatsDaoImpl implements StatsDao {

    @Override
    public int getTotalProducts() {
        String sql = "SELECT COUNT(*) AS cnt FROM products";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt("cnt");
        } catch (SQLException e) {
            System.out.println("getTotalProducts error: " + e.getMessage());
        }
        return 0;
    }

    @Override
    public int getTotalOrders() {
        String sql = "SELECT COUNT(*) AS cnt FROM orders";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt("cnt");
        } catch (SQLException e) {
            System.out.println("getTotalOrders error: " + e.getMessage());
        }
        return 0;
    }

    @Override
    public int getPendingOrders() {
        String sql = "SELECT COUNT(*) AS cnt FROM orders WHERE status = 'PENDING'";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt("cnt");
        } catch (SQLException e) {
            System.out.println("getPendingOrders error: " + e.getMessage());
        }
        return 0;
    }

    @Override
    public int getTotalUsers() {
        String sql = "SELECT COUNT(*) AS cnt FROM users";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt("cnt");
        } catch (SQLException e) {
            System.out.println("getTotalUsers error: " + e.getMessage());
        }
        return 0;
    }

    @Override
    public List<OrderSummary> getRecentOrders(int limit) {
        List<OrderSummary> out = new ArrayList<>();
        String sql = "SELECT o.id, u.username, o.total_price, o.order_date, COALESCE(o.status, 'PENDING') AS status "
                + "FROM orders o LEFT JOIN users u ON o.user_id = u.id "
                + "ORDER BY datetime(o.order_date) DESC LIMIT ?";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String username = rs.getString("username");
                    double total = rs.getDouble("total_price");
                    String orderDate = rs.getString("order_date");
                    String status = rs.getString("status");
                    out.add(new OrderSummary(id, username, total, status, orderDate));
                }
            }
        } catch (SQLException e) {
            System.out.println("getRecentOrders error: " + e.getMessage());
        }
        return out;
    }
}
