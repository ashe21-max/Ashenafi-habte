package com.papantsh.onlineshop.dao;

import java.util.List;
import com.papantsh.onlineshop.Product;

public interface ProductDao {
    List<Product> findAll();
    boolean create(Product p);
    boolean update(Product p);
    boolean delete(int id);
    Product findById(int id);
    boolean setActive(int id, boolean active);
}
