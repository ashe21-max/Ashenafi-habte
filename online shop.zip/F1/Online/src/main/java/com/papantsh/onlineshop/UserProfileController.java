package com.papantsh.onlineshop;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class UserProfileController {

    @FXML private TextField tfUsername;
    @FXML private TextField tfEmail;
    @FXML private TextField tfPhone;
    @FXML private TextField tfAddress;
    @FXML private Label lblCreatedAt;
    @FXML private Label lblStatus;
    @FXML private Button btnSave;
    @FXML private javafx.scene.image.ImageView imgProfile;
    @FXML private Button btnUpload;
    @FXML private Label lblImageStatus;

    @FXML private PasswordField pfCurrent;
    @FXML private PasswordField pfNew;
    @FXML private PasswordField pfConfirm;
    @FXML private Button btnChangePassword;

    public void initialize() {
        // ensure user logged in
        if (CurrentSession.getUserId() <= 0) {
            SceneController sc = new SceneController(Main.mainStage);
            sc.switchTo("login.fxml");
            return;
        }

        // load current user info
        try {
            String username = CurrentSession.getUsername();
            User u = DBHandler.getUserByUsername(username);
            if (u != null) {
                tfUsername.setText(u.getUsername());
                tfEmail.setText(u.getEmail());
                if (tfPhone != null) tfPhone.setText(u.getPhone());
                if (tfAddress != null) tfAddress.setText(u.getAddress());
                lblCreatedAt.setText(u.getCreatedAt() == null ? "" : u.getCreatedAt());
                if (u.getImagePath() != null && !u.getImagePath().isBlank()) {
                    try { imgProfile.setImage(new javafx.scene.image.Image(new java.io.File(u.getImagePath()).toURI().toString())); } catch (Exception ignore) {}
                }
            }
        } catch (Exception ex) {
            lblStatus.setText("Unable to load profile: " + ex.getMessage());
        }

        btnUpload.setOnAction(e -> doUploadImage());

        btnSave.setOnAction(e -> doSave());
        btnChangePassword.setOnAction(e -> doChangePassword());
    }

    private void doSave() {
        String newUser = tfUsername.getText() == null ? "" : tfUsername.getText().trim();
        String newEmail = tfEmail.getText() == null ? "" : tfEmail.getText().trim();
        String newPhone = (tfPhone == null) ? "" : tfPhone.getText().trim();
        String newAddress = (tfAddress == null) ? "" : tfAddress.getText().trim();
        if (newUser.isBlank() || newEmail.isBlank()) {
            lblStatus.setText("Username and email cannot be empty.");
            return;
        }

        // server-side uniqueness checks
        try (Connection conn = DBHandler.connect(); PreparedStatement pu = conn.prepareStatement("SELECT id FROM users WHERE username = ? AND id != ?")) {
            pu.setString(1, newUser);
            pu.setInt(2, CurrentSession.getUserId());
            try (java.sql.ResultSet r = pu.executeQuery()) { if (r.next()) { lblStatus.setText("Username already taken."); return; } }
        } catch (Exception ex) { /* ignore db check failure, proceed */ }
        try (Connection conn = DBHandler.connect(); PreparedStatement pe = conn.prepareStatement("SELECT id FROM users WHERE email = ? AND id != ?")) {
            pe.setString(1, newEmail);
            pe.setInt(2, CurrentSession.getUserId());
            try (java.sql.ResultSet r = pe.executeQuery()) { if (r.next()) { lblStatus.setText("Email already in use."); return; } }
        } catch (Exception ex) { /* ignore */ }

        String sql = "UPDATE users SET username = ?, email = ? WHERE id = ?";
        try (Connection conn = DBHandler.connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newUser);
            ps.setString(2, newEmail);
            ps.setInt(3, CurrentSession.getUserId());
            ps.executeUpdate();
            // update phone/address if present
            try (PreparedStatement ps2 = DBHandler.connect().prepareStatement("UPDATE users SET phone = ?, address = ? WHERE id = ?")) {
                ps2.setString(1, newPhone.isBlank() ? null : newPhone);
                ps2.setString(2, newAddress.isBlank() ? null : newAddress);
                ps2.setInt(3, CurrentSession.getUserId());
                ps2.executeUpdate();
            } catch (Exception ignored) {}
            lblStatus.setStyle("-fx-text-fill: green;");
            lblStatus.setText("Profile updated.");
            // update current session username
            CurrentSession.setUser(CurrentSession.getUserId(), newUser);
        } catch (Exception ex) {
            lblStatus.setText("Update failed: " + ex.getMessage());
        }
    }

    private void doUploadImage() {
        javafx.stage.FileChooser fc = new javafx.stage.FileChooser();
        fc.getExtensionFilters().addAll(new javafx.stage.FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.jpeg", "*.gif"));
        java.io.File f = fc.showOpenDialog(Main.mainStage);
        if (f == null) return;
        try {
            java.nio.file.Path destDir = java.nio.file.Paths.get("data", "profile_images");
            java.nio.file.Files.createDirectories(destDir);
            String name = System.currentTimeMillis() + "_" + f.getName();
            java.nio.file.Path dest = destDir.resolve(name);
            java.nio.file.Files.copy(f.toPath(), dest, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            // update DB
            try (Connection conn = DBHandler.connect(); PreparedStatement ps = conn.prepareStatement("UPDATE users SET profile_image = ? WHERE id = ?")) {
                ps.setString(1, dest.toString());
                ps.setInt(2, CurrentSession.getUserId());
                ps.executeUpdate();
            }
            imgProfile.setImage(new javafx.scene.image.Image(dest.toFile().toURI().toString()));
            lblImageStatus.setText("Profile image uploaded.");
        } catch (Exception ex) {
            lblImageStatus.setText("Upload failed: " + ex.getMessage());
        }
    }

    private void doChangePassword() {
        String cur = pfCurrent.getText() == null ? "" : pfCurrent.getText();
        String n1 = pfNew.getText() == null ? "" : pfNew.getText();
        String n2 = pfConfirm.getText() == null ? "" : pfConfirm.getText();
        if (cur.isBlank() || n1.isBlank() || n2.isBlank()) { lblStatus.setText("Please fill all password fields."); return; }
        if (!n1.equals(n2)) { lblStatus.setText("New passwords do not match."); return; }

        String username = CurrentSession.getUsername();
        if (!DBHandler.validateLogin(username, cur)) { lblStatus.setText("Current password incorrect."); return; }

        String sql = "UPDATE users SET password = ? WHERE id = ?";
        try (Connection conn = DBHandler.connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, DBHandler.hashPassword(n1));
            ps.setInt(2, CurrentSession.getUserId());
            ps.executeUpdate();
            lblStatus.setStyle("-fx-text-fill: green;");
            lblStatus.setText("Password changed.");
            pfCurrent.clear(); pfNew.clear(); pfConfirm.clear();
        } catch (Exception ex) {
            lblStatus.setText("Failed to change password: " + ex.getMessage());
        }
    }

    @FXML
    private void onPrev() {
        new SceneController(Main.mainStage).switchTo("dashboard.fxml");
    }

    @FXML
    private void onNext() {
        new SceneController(Main.mainStage).switchTo("product_list.fxml");
    }
}
