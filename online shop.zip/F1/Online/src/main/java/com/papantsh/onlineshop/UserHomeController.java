package com.papantsh.onlineshop;

import com.papantsh.onlineshop.dao.ProductRecentDao;
import com.papantsh.onlineshop.dao.ProductDaoImpl;
import com.papantsh.onlineshop.dao.StatsDao;
import com.papantsh.onlineshop.dao.StatsDaoImpl;
import com.papantsh.onlineshop.dao.OrderSummary;
import com.papantsh.onlineshop.dao.ProductSummary;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public class UserHomeController {

    @FXML private Label lblWelcome;
    @FXML private Label lblTotalOrders;
    @FXML private Label lblPendingOrders;
    @FXML private Label lblCompletedOrders;
    @FXML private Label lblCartCount;

    @FXML private Button btnStartShopping;
    @FXML private Button btnViewCart;
    @FXML private Button btnOrderHistory;
    @FXML private Button btnHomePrev;
    @FXML private Button btnHomeNext;

    @FXML private TableView<OrderSummary> tblRecentOrders;
    @FXML private TableColumn<OrderSummary, Integer> colOrderId;
    @FXML private TableColumn<OrderSummary, String> colOrderDate;
    @FXML private TableColumn<OrderSummary, String> colOrderStatus;
    @FXML private TableColumn<OrderSummary, Double> colOrderAmount;

    @FXML private HBox hboxProducts;

    private StatsDao statsDao = new StatsDaoImpl();
    private ProductRecentDao productDao = new ProductDaoImpl();

    @FXML
    private void initialize() {
        String username = CurrentSession.getUsername();
        if (username == null || username.isBlank()) username = "Guest";
        lblWelcome.setText("Welcome, " + username + "!");

        loadSummaryCounts();
        loadRecentOrders();
        loadFeaturedProducts();
        btnStartShopping.setOnAction(e -> new SceneController(Main.mainStage).switchTo("product_list.fxml"));
        btnViewCart.setOnAction(e -> new SceneController(Main.mainStage).switchTo("cart.fxml"));
        btnOrderHistory.setOnAction(e -> new SceneController(Main.mainStage).switchTo("orders.fxml"));

        // back / forward navigation (Home page)
        if (btnHomePrev != null) btnHomePrev.setOnAction(e -> new SceneController(Main.mainStage).switchTo("dashboard.fxml"));
        if (btnHomeNext != null) btnHomeNext.setOnAction(e -> new SceneController(Main.mainStage).switchTo("product_list.fxml"));
    }

    @FXML
    private void onPrev() {
        new SceneController(Main.mainStage).switchTo("dashboard.fxml");
    }

    @FXML
    private void onNext() {
        new SceneController(Main.mainStage).switchTo("product_list.fxml");
    }

    private void loadSummaryCounts() {
        int userId = CurrentSession.getUserId();
        if (userId <= 0) {
            lblTotalOrders.setText("0");
            lblPendingOrders.setText("0");
            lblCompletedOrders.setText("0");
            lblCartCount.setText("0");
            return;
        }

        try (Connection c = DBHandler.connect()) {
            try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) AS cnt FROM orders WHERE user_id = ?")) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) { if (rs.next()) lblTotalOrders.setText(String.valueOf(rs.getInt("cnt"))); }
            }
            try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) AS cnt FROM orders WHERE user_id = ? AND status = 'PENDING'")) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) { if (rs.next()) lblPendingOrders.setText(String.valueOf(rs.getInt("cnt"))); }
            }
            try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) AS cnt FROM orders WHERE user_id = ? AND status = 'COMPLETED'")) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) { if (rs.next()) lblCompletedOrders.setText(String.valueOf(rs.getInt("cnt"))); }
            }
            try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) AS cnt FROM cart WHERE user_id = ?")) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) { if (rs.next()) lblCartCount.setText(String.valueOf(rs.getInt("cnt"))); }
            }
        } catch (Exception ex) {
            System.out.println("Error loading summary counts: " + ex.getMessage());
        }
    }

    private void loadRecentOrders() {
        // load last 5 orders for the current user
        ObservableList<OrderSummary> rows = FXCollections.observableArrayList();
        int userId = CurrentSession.getUserId();
        if (userId <= 0) { tblRecentOrders.setItems(rows); return; }

        String sql = "SELECT id, total_price, order_date, COALESCE(status,'PENDING') AS status FROM orders WHERE user_id = ? ORDER BY datetime(order_date) DESC LIMIT 5";
        try (java.sql.Connection conn = DBHandler.connect(); java.sql.PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new OrderSummary(rs.getInt("id"), CurrentSession.getUsername(), rs.getDouble("total_price"), rs.getString("status"), rs.getString("order_date")));
                }
            }
        } catch (Exception ex) {
            System.out.println("Error loading recent orders: " + ex.getMessage());
        }

        // configure columns
        try {
            colOrderId.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getId()).asObject());
            colOrderDate.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getOrderDate()));
            colOrderStatus.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getStatus()));
            colOrderAmount.setCellValueFactory(data -> new javafx.beans.property.SimpleDoubleProperty(data.getValue().getTotal()).asObject());
        } catch (Exception ignore) {}

        tblRecentOrders.setItems(rows);
    }

    private void loadFeaturedProducts() {
        List<ProductSummary> prods = productDao.getRecentProducts(6);
        hboxProducts.getChildren().clear();
        for (ProductSummary p : prods) {
            VBox card = new VBox(6);
            card.setStyle("-fx-background-color: white; -fx-padding:8; -fx-effect: dropshadow(two-pass-box, rgba(0,0,0,0.04), 4,0,0,1);");
            ImageView iv = new ImageView();
            iv.setFitWidth(120); iv.setFitHeight(80); iv.setPreserveRatio(true);
            try {
                if (p.getImagePath() != null && !p.getImagePath().isBlank()) {
                    Image img = new Image(new java.io.File(p.getImagePath()).toURI().toString(), 120, 80, true, true);
                    iv.setImage(img);
                }
            } catch (Exception ignore) {}
            Label name = new Label(p.getName());
            Label price = new Label(String.format("%.2f", p.getPrice()));
            Button btn = new Button("View");
            btn.setOnAction(e -> {
                // open product list focused on this product (simple behavior)
                SceneController sc = new SceneController(Main.mainStage);
                sc.switchTo("product_list.fxml");
            });
            card.getChildren().addAll(iv, name, price, btn);
            hboxProducts.getChildren().add(card);
        }
    }
}
