package com.papantsh.onlineshop;

public class CurrentSession {
    private static int userId = -1;
    private static String username = null;
    private static String role = null;

    public static void setUser(int id, String user) {
        userId = id;
        username = user;
    }

    public static void setRole(String r) { role = r; }

    public static int getUserId() {
        return userId;
    }

    public static String getUsername() {
        return username;
    }

    public static String getRole() { return role; }

    public static void clear() {
        userId = -1;
        username = null;
        role = null;
    }
}
