package com.papantsh.onlineshop.dao;

public class Order {
    private int id;
    private int userId;
    private String userName;
    private double totalPrice;
    private String orderDate;
    private String status;
    private String products = "";

    public Order(int id, int userId, double totalPrice, String orderDate, String status) {
        this.id = id;
        this.userId = userId;
        this.totalPrice = totalPrice;
        this.orderDate = orderDate;
        this.status = status;
        this.userName = "";
    }

    public void setUserName(String name) { this.userName = name; }
    public String getUserName() { return userName; }

    public int getId() { return id; }
    public int getUserId() { return userId; }
    public double getTotalPrice() { return totalPrice; }
    public String getOrderDate() { return orderDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getProducts() { return products; }
    public void setProducts(String products) { this.products = products == null ? "" : products; }
}
