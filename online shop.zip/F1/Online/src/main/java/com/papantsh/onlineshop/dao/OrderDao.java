package com.papantsh.onlineshop.dao;

import java.util.List;

public interface OrderDao {
    List<Order> getAllOrders();
    List<Order> searchOrders(String query, String status, String dateFrom, String dateTo, String sortBy, String sortDir);
    List<Order> getOrdersForUser(int userId);
    List<OrderItem> getOrderItems(int orderId);
    boolean updateOrderStatus(int orderId, String status);
}
