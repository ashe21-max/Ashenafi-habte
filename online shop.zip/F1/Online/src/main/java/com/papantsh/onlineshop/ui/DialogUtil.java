package com.papantsh.onlineshop.ui;

import com.papantsh.onlineshop.LogUtil;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;

import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Dialog utility to centralize dialog behavior. By default the lightweight
 * `confirm` remains for logging/automated tests (auto-accept). For interactive
 * UI flows use `confirmBlocking` which shows a real JavaFX confirmation dialog.
 */
public final class DialogUtil {
    private DialogUtil() {}

    /**
     * Non-blocking confirm used in automated/headless runs (keeps previous behaviour).
     */
    public static boolean confirm(String title, String message) {
        LogUtil.log("INFO", "Confirm requested: " + title + " - " + message + " (auto-accepted)");
        return true; // auto-accept to remove blocking alerts in automated runs
    }

    /**
     * Blocking confirmation dialog shown to the user. Safe to call from any thread.
     * Returns true when user selects Yes.
     */
    public static boolean confirmBlocking(String title, String message) {
        try {
            if (javafx.application.Platform.isFxApplicationThread()) {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle(title);
                alert.setHeaderText(null);
                alert.setContentText(message);
                ButtonType yes = new ButtonType("Yes", ButtonBar.ButtonData.YES);
                ButtonType no = new ButtonType("No", ButtonBar.ButtonData.NO);
                alert.getButtonTypes().setAll(yes, no);
                Optional<ButtonType> opt = alert.showAndWait();
                return opt.isPresent() && opt.get().getButtonData() == ButtonBar.ButtonData.YES;
            } else {
                final AtomicBoolean answer = new AtomicBoolean(false);
                final CountDownLatch latch = new CountDownLatch(1);
                javafx.application.Platform.runLater(() -> {
                    try {
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                        alert.setTitle(title);
                        alert.setHeaderText(null);
                        alert.setContentText(message);
                        ButtonType yes = new ButtonType("Yes", ButtonBar.ButtonData.YES);
                        ButtonType no = new ButtonType("No", ButtonBar.ButtonData.NO);
                        alert.getButtonTypes().setAll(yes, no);
                        Optional<ButtonType> opt = alert.showAndWait();
                        answer.set(opt.isPresent() && opt.get().getButtonData() == ButtonBar.ButtonData.YES);
                    } finally {
                        latch.countDown();
                    }
                });
                try { latch.await(); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
                return answer.get();
            }
        } catch (Throwable t) {
            // fallback to logged auto-accept behaviour on e.g. toolkit not initialized
            LogUtil.log("WARN", "confirmBlocking failed, falling back to auto-accept: " + t.getMessage());
            return true;
        }
    }

    public static void showError(String message) {
        LogUtil.log("ERROR", message);
    }

    public static void showInfo(String message) {
        LogUtil.log("INFO", message);
    }
}
