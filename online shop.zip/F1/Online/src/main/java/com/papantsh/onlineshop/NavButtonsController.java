package com.papantsh.onlineshop;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class NavButtonsController {

    @FXML private Button btnPagePrev;
    @FXML private Button btnPageNext;

    @FXML
    private void onPrev() {
        // Navigate main stage to dashboard
        new SceneController(Main.mainStage).switchTo("dashboard.fxml");
        // if this include is inside a dialog, close that dialog
        try {
            Stage st = (Stage) btnPagePrev.getScene().getWindow();
            if (st != null && st != Main.mainStage) st.close();
        } catch (Exception ignore) {}
    }

    @FXML
    private void onNext() {
        // Navigate main stage to product list
        new SceneController(Main.mainStage).switchTo("product_list.fxml");
        // if this include is inside a dialog, close that dialog
        try {
            Stage st = (Stage) btnPageNext.getScene().getWindow();
            if (st != null && st != Main.mainStage) st.close();
        } catch (Exception ignore) {}
    }
}
