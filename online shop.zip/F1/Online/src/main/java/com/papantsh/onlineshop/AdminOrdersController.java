package com.papantsh.onlineshop;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import com.papantsh.onlineshop.dao.OrderDao;
import com.papantsh.onlineshop.dao.OrderDaoImpl;
import com.papantsh.onlineshop.dao.Order;
import com.papantsh.onlineshop.dao.OrderItem;

import java.util.List;

public class AdminOrdersController {

    @FXML private TableView<Order> tblOrders;
    @FXML private TableColumn<Order, Integer> colId;
    @FXML private TableColumn<Order, String> colUser;
    @FXML private TableColumn<Order, String> colDate;
    @FXML private TableColumn<Order, Double> colTotal;
    @FXML private TableColumn<Order, String> colStatus;

    @FXML private ChoiceBox<String> choiceStatus;
    @FXML private TextField tfSearch;
    @FXML private ChoiceBox<String> choiceStatusFilter;
    @FXML private DatePicker dpFrom;
    @FXML private DatePicker dpTo;
    @FXML private ChoiceBox<String> choiceSortBy;
    @FXML private ChoiceBox<String> choiceSortDir;
    @FXML private Button btnSearch;
    @FXML private Button btnReset;
    @FXML private Button btnUpdateStatus;

    @FXML private TableView<OrderItem> tblOrderItems;
    @FXML private TableColumn<OrderItem, String> colItemName;
    @FXML private TableColumn<OrderItem, Integer> colItemQty;
    @FXML private TableColumn<OrderItem, Double> colItemPrice;

    private OrderDao dao = new OrderDaoImpl();

    @FXML
    private void initialize() {
        // configure columns
        if (colId != null) colId.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("id"));
        if (colUser != null) colUser.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("userName"));
        if (colDate != null) colDate.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("orderDate"));
        if (colTotal != null) colTotal.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("totalPrice"));
        if (colStatus != null) colStatus.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("status"));

        if (colItemName != null) colItemName.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("productName"));
        if (colItemQty != null) colItemQty.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("quantity"));
        if (colItemPrice != null) colItemPrice.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("price"));

        // populate status choices
        if (choiceStatus != null) {
            choiceStatus.setItems(FXCollections.observableArrayList("PENDING", "PROCESSING", "COMPLETED", "CANCELLED"));
            choiceStatus.setValue("PENDING");
        }

        // prepare search/filter/sort controls
        if (choiceStatusFilter != null) {
            choiceStatusFilter.setItems(FXCollections.observableArrayList("ALL", "PENDING", "PROCESSING", "COMPLETED", "CANCELLED"));
            choiceStatusFilter.setValue("ALL");
        }
        if (choiceSortBy != null) {
            choiceSortBy.setItems(FXCollections.observableArrayList("date", "total", "status"));
            choiceSortBy.setValue("date");
        }
        if (choiceSortDir != null) {
            choiceSortDir.setItems(FXCollections.observableArrayList("desc", "asc"));
            choiceSortDir.setValue("desc");
        }

        if (btnSearch != null) btnSearch.setOnAction(e -> doSearch());
        if (btnReset != null) btnReset.setOnAction(e -> doReset());

        refreshOrders(null, null, null, null);

        if (tblOrders != null) {
            tblOrders.getSelectionModel().selectedItemProperty().addListener((obs, oldv, newv) -> {
                if (newv != null) showOrderItems(newv.getId());
            });
        }

        if (btnUpdateStatus != null) {
            btnUpdateStatus.setOnAction(e -> {
                Order sel = tblOrders.getSelectionModel().getSelectedItem();
                String st = choiceStatus.getValue();
                if (sel == null) return;
                if (st == null || st.isEmpty()) return;
                boolean ok = dao.updateOrderStatus(sel.getId(), st);
                if (ok) {
                    sel.setStatus(st);
                    tblOrders.refresh();
                }
            });
        }
    }

    private void refreshOrders(String query, String status, String dateFrom, String dateTo) {
        String sortBy = choiceSortBy == null ? null : choiceSortBy.getValue();
        String sortDir = choiceSortDir == null ? null : choiceSortDir.getValue();
        List<Order> list = dao.searchOrders(query, (status == null || "ALL".equalsIgnoreCase(status)) ? null : status, dateFrom, dateTo, sortBy, sortDir);
        ObservableList<Order> rows = FXCollections.observableArrayList(list);
        if (tblOrders != null) tblOrders.setItems(rows);
    }

    private void doSearch() {
        String q = tfSearch == null ? null : tfSearch.getText();
        String status = choiceStatusFilter == null ? null : choiceStatusFilter.getValue();
        String from = dpFrom == null || dpFrom.getValue() == null ? null : dpFrom.getValue().toString();
        String to = dpTo == null || dpTo.getValue() == null ? null : dpTo.getValue().toString();
        refreshOrders(q, status, from, to);
    }

    private void doReset() {
        if (tfSearch != null) tfSearch.clear();
        if (choiceStatusFilter != null) choiceStatusFilter.setValue("ALL");
        if (dpFrom != null) dpFrom.setValue(null);
        if (dpTo != null) dpTo.setValue(null);
        if (choiceSortBy != null) choiceSortBy.setValue("date");
        if (choiceSortDir != null) choiceSortDir.setValue("desc");
        refreshOrders(null, null, null, null);
    }

    private void showOrderItems(int orderId) {
        List<OrderItem> items = dao.getOrderItems(orderId);
        ObservableList<OrderItem> rows = FXCollections.observableArrayList(items);
        if (tblOrderItems != null) tblOrderItems.setItems(rows);
    }
}
