package com.papantsh.onlineshop;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.sql.*;

public class AdminUsersController {

    @FXML private TableView<User> tableUsers;
    @FXML private TableColumn<User, Integer> colId;
    @FXML private TableColumn<User, String> colUsername;
    @FXML private TableColumn<User, String> colEmail;
    @FXML private TableColumn<User, String> colRole;
    @FXML private TableColumn<User, String> colStatus;
    @FXML private TableColumn<User, String> colCreatedAt;
    @FXML private Button btnViewOrders;
    @FXML private Button btnToggle;
    @FXML private Button btnReset;
    @FXML private Button btnRefresh;
    @FXML private Label statusLabel;

    private ObservableList<User> userList = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        colId.setCellValueFactory(data -> data.getValue().idProperty().asObject());
        colUsername.setCellValueFactory(data -> data.getValue().usernameProperty());
        colEmail.setCellValueFactory(data -> data.getValue().emailProperty());
        colRole.setCellValueFactory(data -> data.getValue().roleProperty());
        colStatus.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().isActive() ? "Enabled" : "Disabled"));
        colCreatedAt.setCellValueFactory(data -> data.getValue().createdAtProperty());

        loadUsers();

        btnRefresh.setOnAction(e -> loadUsers());

        btnReset.setOnAction(e -> {
            User selected = tableUsers.getSelectionModel().getSelectedItem();
            if (selected == null) {
                statusLabel.setText("Select a user first.");
                return;
            }
            // Ask for a new password (admin-set)
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Reset password");
            dialog.setHeaderText("Reset password for: " + selected.getUsername());
            dialog.setContentText("New password (leave empty to cancel):");
            java.util.Optional<String> res = dialog.showAndWait();
            if (res.isEmpty() || res.get().trim().isEmpty()) {
                statusLabel.setText("Password reset cancelled.");
                return;
            }
            String newpass = res.get().trim();
            String sql = "UPDATE users SET password=? WHERE id=?";
            try (Connection conn = DBHandler.connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, DBHandler.hashPassword(newpass));
                ps.setInt(2, selected.getId());
                ps.executeUpdate();
                statusLabel.setStyle("-fx-text-fill: green;");
                statusLabel.setText("Password updated.");
            } catch (SQLException ex) {
                statusLabel.setText("Error: " + ex.getMessage());
            }
        });

        if (btnToggle != null) {
            btnToggle.setOnAction(e -> {
                User selected = tableUsers.getSelectionModel().getSelectedItem();
                if (selected == null) {
                    statusLabel.setText("Select a user first.");
                    return;
                }
                boolean newState = !selected.isActive();
                if (!com.papantsh.onlineshop.ui.DialogUtil.confirm((newState ? "Enable" : "Disable") + " user", "Are you sure you want to " + (newState ? "enable" : "disable") + " user: " + selected.getUsername() + "?")) return;

                String sql = "UPDATE users SET active = ? WHERE id = ?";
                try (Connection conn = DBHandler.connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setInt(1, newState ? 1 : 0);
                    ps.setInt(2, selected.getId());
                    ps.executeUpdate();
                    selected.setActive(newState);
                    tableUsers.refresh();
                    statusLabel.setStyle("-fx-text-fill: green;");
                    statusLabel.setText(newState ? "User enabled." : "User disabled.");
                } catch (SQLException ex) {
                    statusLabel.setText("Error: " + ex.getMessage());
                }
            });
        }

        if (btnViewOrders != null) {
            btnViewOrders.setOnAction(e -> {
                User selected = tableUsers.getSelectionModel().getSelectedItem();
                if (selected == null) {
                    statusLabel.setText("Select a user first.");
                    return;
                }
                // open order history for this user
                try {
                    javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("/fxml/admin_user_orders.fxml"));
                    javafx.scene.Parent root = loader.load();
                    AdminUserOrdersController controller = loader.getController();
                    controller.setUserId(selected.getId());
                    controller.setUsername(selected.getUsername());

                    javafx.stage.Stage st = new javafx.stage.Stage();
                    st.setTitle("Orders: " + selected.getUsername());
                    st.setScene(new javafx.scene.Scene(root));
                    st.initOwner(Main.mainStage);
                    st.show();
                } catch (Exception ex) {
                    statusLabel.setText("Unable to open orders: " + ex.getMessage());
                }
            });
        }
    }

    private void loadUsers() {
        userList.clear();
        String sql = "SELECT id, username, email, role, coalesce(active,1) as active, created_at FROM users";

        try (Connection conn = DBHandler.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                User user = new User(
                    rs.getInt("id"),
                    rs.getString("username"),
                    rs.getString("email"),
                    rs.getString("role"),
                    "" // password not needed for table
                );
                try { user.setActive(rs.getInt("active") == 1); } catch (Exception ignored) {}
                try { user.setCreatedAt(rs.getString("created_at")); } catch (Exception ignored) {}
                userList.add(user);
            }

            tableUsers.setItems(userList);

        } catch (SQLException e) {
            statusLabel.setText("Error loading users: " + e.getMessage());
        }
    }
}
