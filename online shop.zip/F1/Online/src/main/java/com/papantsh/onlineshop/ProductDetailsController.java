package com.papantsh.onlineshop;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.File;

public class ProductDetailsController {

    @FXML private ImageView ivProduct;
    @FXML private Label lblName;
    @FXML private Label lblCategory;
    @FXML private Label lblPrice;
    @FXML private Label lblStock;
    @FXML private TextArea txtDescription;
    @FXML private Button btnClose;

    public void initialize() {
        btnClose.setOnAction(e -> {
            Stage st = (Stage) btnClose.getScene().getWindow();
            st.close();
        });
    }

    @FXML
    private void onPrev() {
        // close this details window
        try {
            Stage st = (Stage) btnClose.getScene().getWindow();
            st.close();
        } catch (Exception ignore) {}
    }

    @FXML
    private void onNext() {
        // open shop in main stage and close this dialog
        new SceneController(Main.mainStage).switchTo("product_list.fxml");
        try { Stage st = (Stage) btnClose.getScene().getWindow(); st.close(); } catch (Exception ignore) {}
    }

    public void setProduct(Product p) {
        if (p == null) return;
        lblName.setText(p.getName());
        lblCategory.setText("Category: " + (p.getCategory() == null || p.getCategory().isBlank() ? "—" : p.getCategory()));
        lblPrice.setText(String.format("Price: %.2f Birr", p.getPrice()));
        lblStock.setText("Stock: " + p.getStock());
        txtDescription.setText(p.getDescription());

        String path = p.getImagePath();
        if (path != null && !path.isBlank()) {
            try {
                File f = new File(path);
                File thumb = new File(f.getParentFile(), "thumbs" + File.separator + f.getName());
                File load = thumb.exists() ? thumb : f;
                Image img = new Image(load.toURI().toString(), 320, 240, true, true);
                ivProduct.setImage(img);
            } catch (Exception ignored) {}
        }
    }
}
