package com.papantsh.onlineshop.dao;

import java.util.List;
import com.papantsh.onlineshop.dao.OrderSummary;

public interface StatsDao {
    int getTotalProducts();
    int getTotalOrders();
    int getPendingOrders();
    int getTotalUsers();
    List<OrderSummary> getRecentOrders(int limit);
}
