package com.papantsh.onlineshop;

import javafx.beans.property.*;

public class Product {
    private final IntegerProperty id;
    private final StringProperty name;
    private final StringProperty description;
    private final DoubleProperty price;
    private final IntegerProperty stock;
    private final StringProperty category;
    private final StringProperty imagePath;
    private final BooleanProperty active;
    private final StringProperty createdAt;

    public Product(int id, String name, String description, double price, int stock, String category, String imagePath, String createdAt, boolean active) {
        this.id = new SimpleIntegerProperty(id);
        this.name = new SimpleStringProperty(name);
        this.description = new SimpleStringProperty(description);
        this.price = new SimpleDoubleProperty(price);
        this.stock = new SimpleIntegerProperty(stock);
        this.category = new SimpleStringProperty(category == null ? "" : category);
        this.imagePath = new SimpleStringProperty(imagePath == null ? "" : imagePath);
        this.active = new SimpleBooleanProperty(active);
        this.createdAt = new SimpleStringProperty(createdAt == null ? "" : createdAt);
    }

    // For creating new products (id = 0)
    public Product(String name, String description, double price, int stock) {
        this(0, name, description, price, stock, "", "", null, true);
    }

    public IntegerProperty idProperty() { return id; }
    public StringProperty nameProperty() { return name; }
    public StringProperty descriptionProperty() { return description; }
    public DoubleProperty priceProperty() { return price; }
    public IntegerProperty stockProperty() { return stock; }
    public StringProperty categoryProperty() { return category; }
    public StringProperty imagePathProperty() { return imagePath; }
    public BooleanProperty activeProperty() { return active; }
    public StringProperty createdAtProperty() { return createdAt; }

    public int getId() { return id.get(); }
    public String getName() { return name.get(); }
    public String getDescription() { return description.get(); }
    public double getPrice() { return price.get(); }
    public int getStock() { return stock.get(); }
    public String getCategory() { return category.get(); }
    public String getImagePath() { return imagePath.get(); }
    public boolean isActive() { return active.get(); }
    public String getCreatedAt() { return createdAt.get(); }

    public void setName(String name) { this.name.set(name); }
    public void setDescription(String description) { this.description.set(description); }
    public void setPrice(double price) { this.price.set(price); }
    public void setStock(int stock) { this.stock.set(stock); }
    public void setCategory(String category) { this.category.set(category); }
    public void setImagePath(String path) { this.imagePath.set(path); }
    public void setActive(boolean val) { this.active.set(val); }
}
