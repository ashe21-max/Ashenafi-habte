package com.papantsh.onlineshop;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class LogUtil {
    private static final Path LOG_DIR = Paths.get("logs");
    private static final Path LOG_FILE = LOG_DIR.resolve("app.log");

    public static void ensureLogFile() {
        try {
            if (!Files.exists(LOG_DIR)) Files.createDirectories(LOG_DIR);
            if (!Files.exists(LOG_FILE)) Files.createFile(LOG_FILE);
        } catch (IOException e) {
            System.out.println("Could not create log file: " + e.getMessage());
        }
    }

    public static void log(String level, String message) {
        ensureLogFile();
        String line = java.time.LocalDateTime.now() + " [" + level + "] " + message + System.lineSeparator();
        try (OutputStream os = new BufferedOutputStream(new FileOutputStream(LOG_FILE.toFile(), true))) {
            os.write(line.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.out.println("log write failed: " + e.getMessage());
        }
    }

    public static List<String> tail(int lines) {
        ensureLogFile();
        try {
            List<String> all = Files.readAllLines(LOG_FILE, StandardCharsets.UTF_8);
            int size = all.size();
            int from = Math.max(0, size - lines);
            return new ArrayList<>(all.subList(from, size));
        } catch (IOException e) {
            return List.of("Unable to read logs: " + e.getMessage());
        }
    }

    public static void clear() {
        ensureLogFile();
        try (PrintWriter pw = new PrintWriter(LOG_FILE.toFile())) { pw.print(""); }
        catch (FileNotFoundException e) {
            System.out.println("Could not clear log: " + e.getMessage());
        }
    }
}
