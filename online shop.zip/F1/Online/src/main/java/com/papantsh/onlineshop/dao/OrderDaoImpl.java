package com.papantsh.onlineshop.dao;

import com.papantsh.onlineshop.DBHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderDaoImpl implements OrderDao {

    @Override
    public List<Order> getAllOrders() {
        List<Order> out = new ArrayList<>();
        String sql = "SELECT o.id, o.user_id, u.username, o.total_price, o.order_date, COALESCE(o.status,'PENDING') as status, "
            + "(SELECT GROUP_CONCAT(p.name, ', ') FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = o.id) AS products "
            + "FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY datetime(o.order_date) DESC";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Order o = new Order(
                    rs.getInt("id"),
                    rs.getInt("user_id"),
                    rs.getDouble("total_price"),
                    rs.getString("order_date"),
                    rs.getString("status")
                );
                try { o.setUserName(rs.getString("username")); } catch (Exception ignored) {}
                try { o.setProducts(rs.getString("products")); } catch (Exception ignored) {}
                out.add(o);
            }
        } catch (SQLException e) {
            System.out.println("getAllOrders error: " + e.getMessage());
        }
        return out;
    }

    @Override
    public List<Order> searchOrders(String query, String status, String dateFrom, String dateTo, String sortBy, String sortDir) {
        List<Order> out = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT o.id, o.user_id, u.username, o.total_price, o.order_date, COALESCE(o.status,'PENDING') as status, "
            + "(SELECT GROUP_CONCAT(p.name, ', ') FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = o.id) AS products "
            + "FROM orders o LEFT JOIN users u ON o.user_id = u.id WHERE 1=1");
        if (query != null && !query.trim().isEmpty()) {
            sb.append(" AND (");
            // numeric query -> match order id or user id
            boolean isNum = query.matches("\\d+");
            if (isNum) {
                sb.append(" o.id = ? OR o.user_id = ? ");
            } else {
                sb.append(" u.username LIKE ? ");
            }
            sb.append(" )");
        }
        if (status != null && !status.isBlank()) {
            sb.append(" AND o.status = ?");
        }
        if (dateFrom != null && !dateFrom.isBlank()) {
            sb.append(" AND datetime(o.order_date) >= datetime(?)");
        }
        if (dateTo != null && !dateTo.isBlank()) {
            sb.append(" AND datetime(o.order_date) <= datetime(?)");
        }

        // sort
        String sortColumn = "datetime(o.order_date)";
        if ("total".equalsIgnoreCase(sortBy)) sortColumn = "o.total_price";
        if ("status".equalsIgnoreCase(sortBy)) sortColumn = "o.status";
        String dir = "DESC";
        if ("asc".equalsIgnoreCase(sortDir)) dir = "ASC";
        sb.append(" ORDER BY ").append(sortColumn).append(" ").append(dir);

        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sb.toString())) {
            int idx = 1;
            if (query != null && !query.trim().isEmpty()) {
                boolean isNum = query.matches("\\d+");
                if (isNum) {
                    ps.setInt(idx++, Integer.parseInt(query));
                    ps.setInt(idx++, Integer.parseInt(query));
                } else {
                    ps.setString(idx++, "%" + query + "%");
                }
            }
            if (status != null && !status.isBlank()) ps.setString(idx++, status);
            if (dateFrom != null && !dateFrom.isBlank()) ps.setString(idx++, dateFrom);
            if (dateTo != null && !dateTo.isBlank()) ps.setString(idx++, dateTo);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Order o = new Order(
                            rs.getInt("id"),
                            rs.getInt("user_id"),
                            rs.getDouble("total_price"),
                            rs.getString("order_date"),
                            rs.getString("status")
                    );
                    try { o.setUserName(rs.getString("username")); } catch (Exception ignored) {}
                    try { o.setProducts(rs.getString("products")); } catch (Exception ignored) {}
                    out.add(o);
                }
            }
        } catch (SQLException e) {
            System.out.println("searchOrders error: " + e.getMessage());
        }

        return out;
    }

    @Override
    public List<OrderItem> getOrderItems(int orderId) {
        List<OrderItem> out = new ArrayList<>();
        String sql = "SELECT oi.id, oi.order_id, oi.product_id, p.name AS product_name, oi.quantity, oi.price "
                + "FROM order_items oi LEFT JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.add(new OrderItem(
                            rs.getInt("id"),
                            rs.getInt("order_id"),
                            rs.getInt("product_id"),
                            rs.getString("product_name"),
                            rs.getInt("quantity"),
                            rs.getDouble("price")
                    ));
                }
            }
        } catch (SQLException e) {
            System.out.println("getOrderItems error: " + e.getMessage());
        }
        return out;
    }

    @Override
    public List<Order> getOrdersForUser(int userId) {
        List<Order> out = new ArrayList<>();
        String sql = "SELECT o.id, o.user_id, u.username, o.total_price, o.order_date, COALESCE(o.status,'PENDING') as status, "
            + "(SELECT GROUP_CONCAT(p.name, ', ') FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = o.id) AS products "
            + "FROM orders o LEFT JOIN users u ON o.user_id = u.id WHERE o.user_id = ? ORDER BY datetime(o.order_date) DESC";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Order o = new Order(
                            rs.getInt("id"),
                            rs.getInt("user_id"),
                            rs.getDouble("total_price"),
                            rs.getString("order_date"),
                            rs.getString("status")
                    );
                    try { o.setUserName(rs.getString("username")); } catch (Exception ignored) {}
                    try { o.setProducts(rs.getString("products")); } catch (Exception ignored) {}
                    out.add(o);
                }
            }
        } catch (SQLException e) {
            System.out.println("getOrdersForUser error: " + e.getMessage());
        }
        return out;
    }

    @Override
    public boolean updateOrderStatus(int orderId, String status) {
        String sql = "UPDATE orders SET status = ? WHERE id = ?";
        try (Connection c = DBHandler.connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, orderId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("updateOrderStatus error: " + e.getMessage());
            return false;
        }
    }
}
