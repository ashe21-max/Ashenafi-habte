package com.papantsh.onlineshop.ui;

public class NotificationUtil {
    // Disabled: make all notification methods no-ops to remove toast/popups globally
    public static void showInfo(String message) { /* no-op */ }
    public static void showSuccess(String message) { /* no-op */ }
    public static void showError(String message) { /* no-op */ }
}
