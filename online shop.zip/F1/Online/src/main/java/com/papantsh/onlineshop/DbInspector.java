package com.papantsh.onlineshop;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DbInspector {
    public static void main(String[] args) {
        // ensure tables / migrations are applied
        DBHandler.createTables();

        String sql = "SELECT id, username, email, password, role, created_at FROM users";
        try (Connection conn = DBHandler.connect();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("Users in database:");
            while (rs.next()) {
                System.out.printf("id=%d, username=%s, email=%s, password=%s, role=%s, created_at=%s%n",
                        rs.getInt("id"), rs.getString("username"), rs.getString("email"),
                        rs.getString("password"), rs.getString("role"), rs.getString("created_at"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
