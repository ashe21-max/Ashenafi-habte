package com.papantsh.onlineshop;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import com.papantsh.onlineshop.dao.OrderDao;
import com.papantsh.onlineshop.dao.OrderDaoImpl;
import com.papantsh.onlineshop.dao.Order;
import com.papantsh.onlineshop.dao.OrderItem;

import java.util.List;

public class AdminUserOrdersController {

    @FXML private Label lblTitle;
    @FXML private TableView<Order> tblOrders;
    @FXML private TableColumn<Order, Integer> colId;
    @FXML private TableColumn<Order, String> colDate;
    @FXML private TableColumn<Order, Double> colTotal;
    @FXML private TableColumn<Order, String> colStatus;

    @FXML private TableView<OrderItem> tblOrderItems;
    @FXML private TableColumn<OrderItem, String> colItemName;
    @FXML private TableColumn<OrderItem, Integer> colItemQty;
    @FXML private TableColumn<OrderItem, Double> colItemPrice;

    @FXML private Button btnClose;

    private OrderDao dao = new OrderDaoImpl();
    private int userId;

    public void setUserId(int id) { this.userId = id; loadForUser(); }
    public void setUsername(String name) { if (lblTitle != null) lblTitle.setText("Orders for " + name); }

    @FXML
    private void initialize() {
        if (colId != null) colId.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("id"));
        if (colDate != null) colDate.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("orderDate"));
        if (colTotal != null) colTotal.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("totalPrice"));
        if (colStatus != null) colStatus.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("status"));

        if (colItemName != null) colItemName.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("productName"));
        if (colItemQty != null) colItemQty.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("quantity"));
        if (colItemPrice != null) colItemPrice.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("price"));

        if (tblOrders != null) {
            tblOrders.getSelectionModel().selectedItemProperty().addListener((obs, oldv, newv) -> {
                if (newv != null) showOrderItems(newv.getId());
            });
        }

        if (btnClose != null) btnClose.setOnAction(e -> {
            try { ((javafx.stage.Stage) btnClose.getScene().getWindow()).close(); } catch (Exception ignored) {}
        });
    }

    private void loadForUser() {
        if (userId <= 0) return;
        List<Order> orders = dao.getOrdersForUser(userId);
        ObservableList<Order> rows = FXCollections.observableArrayList(orders);
        if (tblOrders != null) tblOrders.setItems(rows);
    }

    private void showOrderItems(int orderId) {
        List<OrderItem> items = dao.getOrderItems(orderId);
        ObservableList<OrderItem> rows = FXCollections.observableArrayList(items);
        if (tblOrderItems != null) tblOrderItems.setItems(rows);
    }
}
