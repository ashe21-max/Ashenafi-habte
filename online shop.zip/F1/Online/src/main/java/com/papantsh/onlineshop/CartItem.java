package com.papantsh.onlineshop;

import javafx.beans.property.*;

public class CartItem {
    private final IntegerProperty id;
    private final IntegerProperty productId;
    private final StringProperty productName;
    private final IntegerProperty quantity;
    private final DoubleProperty price;
    private final DoubleProperty total;
    private final StringProperty imagePath;

    public CartItem(int id, int productId, String productName, int quantity, double price) {
        this.id = new SimpleIntegerProperty(id);
        this.productId = new SimpleIntegerProperty(productId);
        this.productName = new SimpleStringProperty(productName);
        this.quantity = new SimpleIntegerProperty(quantity);
        this.price = new SimpleDoubleProperty(price);
        this.total = new SimpleDoubleProperty(price * quantity);
        this.imagePath = new SimpleStringProperty("");

        // keep total in sync when quantity changes
        this.quantity.addListener((obs, oldV, newV) -> {
            this.total.set(this.price.get() * newV.intValue());
        });
    }

    public CartItem(int id, int productId, String productName, int quantity, double price, String imagePath) {
        this(id, productId, productName, quantity, price);
        this.imagePath.set(imagePath == null ? "" : imagePath);
    }

    public int getId() { return id.get(); }
    public int getProductId() { return productId.get(); }
    public String getProductName() { return productName.get(); }
    public int getQuantity() { return quantity.get(); }
    public double getPrice() { return price.get(); }
    public double getTotal() { return total.get(); }

    public void setQuantity(int q) { this.quantity.set(q); }


    public IntegerProperty idProperty() { return id; }
    public IntegerProperty productIdProperty() { return productId; }
    public StringProperty productNameProperty() { return productName; }
    public IntegerProperty quantityProperty() { return quantity; }
    public DoubleProperty priceProperty() { return price; }
    public DoubleProperty totalProperty() { return total; }

    public String getImagePath() { return imagePath.get(); }
    public StringProperty imagePathProperty() { return imagePath; }
}

