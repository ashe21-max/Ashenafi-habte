package com.papantsh.onlineshop;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

// removed unused java.sql import

public class AdminProductsController {

    @FXML private TableView<Product> tableProducts;
    @FXML private TableColumn<Product, Integer> colId;
    @FXML private TableColumn<Product, String> colName;
    @FXML private TableColumn<Product, String> colDescription;
    @FXML private TableColumn<Product, String> colCategory;
    @FXML private TableColumn<Product, Double> colPrice;
    @FXML private TableColumn<Product, Integer> colStock;
    @FXML private TableColumn<Product, String> colStatus;
    @FXML private TableColumn<Product, String> colImage;
    @FXML private Label statusLabel;
    @FXML private Button btnBack;
    @FXML private TextField tfSearch;
    @FXML private ComboBox<String> cbCategory;
    @FXML private Button btnFilter;
    @FXML private Button btnClear;

    private ObservableList<Product> productList = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        colId.setCellValueFactory(data -> data.getValue().idProperty().asObject());
        colName.setCellValueFactory(data -> data.getValue().nameProperty());
        colDescription.setCellValueFactory(data -> data.getValue().descriptionProperty());
        colCategory.setCellValueFactory(data -> data.getValue().categoryProperty());
        colImage.setCellValueFactory(data -> data.getValue().imagePathProperty());
        colStatus.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().isActive() ? "Enabled" : "Disabled"));
        colImage.setCellFactory(col -> new javafx.scene.control.TableCell<>() {
            private final javafx.scene.image.ImageView iv = new javafx.scene.image.ImageView();
            {
                iv.setFitWidth(80);
                iv.setFitHeight(60);
                iv.setPreserveRatio(true);
            }
            @Override
            protected void updateItem(String path, boolean empty) {
                super.updateItem(path, empty);
                if (empty || path == null || path.isBlank()) {
                    setGraphic(null);
                } else {
                    try {
                        java.io.File f = new java.io.File(path);
                        java.io.File thumb = new java.io.File(f.getParentFile(), "thumbs" + java.io.File.separator + f.getName());
                        java.io.File load = thumb.exists() ? thumb : f;
                        javafx.scene.image.Image img = new javafx.scene.image.Image(load.toURI().toString(), 80, 60, true, true);
                        iv.setImage(img);
                        setGraphic(iv);
                    } catch (Exception ex) {
                        setGraphic(null);
                    }
                }
            }
        });
        colPrice.setCellValueFactory(data -> data.getValue().priceProperty().asObject());
        colStock.setCellValueFactory(data -> data.getValue().stockProperty().asObject());

        // populate categories for admin filter
        com.papantsh.onlineshop.dao.CategoryDao catDao = new com.papantsh.onlineshop.dao.CategoryDaoImpl();
        cbCategory.getItems().add("All");
        for (com.papantsh.onlineshop.dao.Category c : catDao.findAll()) cbCategory.getItems().add(c.getName());
        cbCategory.getSelectionModel().select("All");

        btnFilter.setOnAction(e -> {
            String q = tfSearch.getText() == null ? null : tfSearch.getText().trim();
            String cat = cbCategory.getSelectionModel().getSelectedItem();
            if (cat != null && (cat.equals("All") || cat.isBlank())) cat = null;
            loadProducts(q, cat);
        });

        btnClear.setOnAction(e -> {
            tfSearch.clear();
            cbCategory.getSelectionModel().select("All");
            loadProducts(null, null);
        });

        loadProducts(null, null);

        btnBack.setOnAction(e -> {
            SceneController sc = new SceneController(Main.mainStage);
            if (CurrentSession.getRole() != null && CurrentSession.getRole().equalsIgnoreCase("ADMIN")) {
                sc.switchTo("admin_dashboard.fxml");
            } else {
                sc.switchTo("dashboard.fxml");
            }
        });
    }

    private void loadProducts() {
        loadProducts(null, null);
    }

    private void loadProducts(String query, String category) {
        productList.clear();
        // use Product DAO for loading
        com.papantsh.onlineshop.dao.ProductDao dao = new com.papantsh.onlineshop.dao.ProductCrudDaoImpl();
        productList.clear();
        for (Product p : dao.findAll()) {
            boolean matches = true;
            if (query != null && !query.isBlank()) {
                String q = query.toLowerCase();
                matches = p.getName().toLowerCase().contains(q) || p.getDescription().toLowerCase().contains(q);
            }
            if (matches && category != null && !category.isBlank()) {
                matches = p.getCategory() != null && p.getCategory().equalsIgnoreCase(category);
            }
            if (matches) productList.add(p);
        }
        tableProducts.setItems(productList);
    }

    @FXML
    private void onAddProduct() {
        ProductDialog dialog = new ProductDialog(null);
        Product result = dialog.showAndWait();
        if (result != null) {
            com.papantsh.onlineshop.dao.ProductDao dao = new com.papantsh.onlineshop.dao.ProductCrudDaoImpl();
            boolean ok = dao.create(result);
            if (ok) {
                loadProducts();
                statusLabel.setStyle("-fx-text-fill: green;");
                statusLabel.setText("Product added successfully.");
            } else {
                statusLabel.setText("Error adding product.");
            }
        }
    }

    @FXML
    private void onEditProduct() {
        Product selected = tableProducts.getSelectionModel().getSelectedItem();
        if (selected == null) {
            statusLabel.setText("Select a product to edit.");
            return;
        }

        ProductDialog dialog = new ProductDialog(selected);
        Product result = dialog.showAndWait();
        if (result != null) {
            // keep same id for update
            result.setName(result.getName());
            result.setDescription(result.getDescription());
            result.setPrice(result.getPrice());
            result.setStock(result.getStock());
            result.setCategory(result.getCategory());
            result.setImagePath(result.getImagePath());
            // assign id to result by creating new Product with id
            Product updated = new Product(selected.getId(), result.getName(), result.getDescription(), result.getPrice(), result.getStock(), result.getCategory(), result.getImagePath(), selected.getCreatedAt(), selected.isActive());
            com.papantsh.onlineshop.dao.ProductDao dao = new com.papantsh.onlineshop.dao.ProductCrudDaoImpl();
            boolean ok = dao.update(updated);
            if (ok) {
                loadProducts();
                statusLabel.setStyle("-fx-text-fill: green;");
                statusLabel.setText("Product updated successfully.");
            } else {
                statusLabel.setText("Error updating product.");
            }
        }
    }

    @FXML
    private void onDeleteProduct() {
        Product selected = tableProducts.getSelectionModel().getSelectedItem();
        if (selected == null) {
            statusLabel.setText("Select a product to delete.");
            return;
        }
        // Use non-blocking confirm (auto-accepted) and avoid alerts
        boolean confirmed = com.papantsh.onlineshop.ui.DialogUtil.confirm("Confirm", "Are you sure you want to " + (selected.isActive() ? "disable" : "enable") + " this product?");
        if (!confirmed) return;

        com.papantsh.onlineshop.dao.ProductDao dao = new com.papantsh.onlineshop.dao.ProductCrudDaoImpl();
        boolean newState = !selected.isActive();
        boolean ok = dao.setActive(selected.getId(), newState);
        if (ok) {
            loadProducts();
            statusLabel.setStyle("-fx-text-fill: green;");
            statusLabel.setText(newState ? "Product enabled." : "Product disabled.");
        } else {
            statusLabel.setText("Error changing product state.");
        }
    }
}
