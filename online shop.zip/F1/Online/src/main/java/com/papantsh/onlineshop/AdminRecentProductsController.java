package com.papantsh.onlineshop;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import com.papantsh.onlineshop.dao.ProductRecentDao;
import com.papantsh.onlineshop.dao.ProductDaoImpl;
import com.papantsh.onlineshop.dao.ProductSummary;

import java.util.List;

public class AdminRecentProductsController {

    @FXML private TableView<ProductSummary> tblRecentProducts;
    @FXML private TableColumn<ProductSummary, Integer> colPId;
    @FXML private TableColumn<ProductSummary, String> colPName;
    @FXML private TableColumn<ProductSummary, String> colPImage;
    @FXML private TableColumn<ProductSummary, Double> colPPrice;
    @FXML private TableColumn<ProductSummary, Integer> colPStock;

    private ProductRecentDao dao = new ProductDaoImpl();

    @FXML
    private void initialize() {
        if (colPId != null) colPId.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("id"));
        if (colPName != null) colPName.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("name"));
        if (colPImage != null) colPImage.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("imagePath"));
        if (colPImage != null) colPImage.setCellFactory(col -> new javafx.scene.control.TableCell<>() {
            private final javafx.scene.image.ImageView iv = new javafx.scene.image.ImageView();
            {
                iv.setFitWidth(100);
                iv.setFitHeight(80);
                iv.setPreserveRatio(true);
            }
            @Override
            protected void updateItem(String path, boolean empty) {
                super.updateItem(path, empty);
                if (empty || path == null || path.isBlank()) {
                    setGraphic(null);
                } else {
                    try {
                        java.io.File f = new java.io.File(path);
                        javafx.scene.image.Image img = new javafx.scene.image.Image(f.toURI().toString(), 100, 80, true, true);
                        iv.setImage(img);
                        setGraphic(iv);
                    } catch (Exception ex) {
                        setGraphic(null);
                    }
                }
            }
        });
        if (colPPrice != null) colPPrice.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("price"));
        if (colPStock != null) colPStock.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("stock"));

        refresh();
    }

    private void refresh() {
        List<ProductSummary> list = dao.getRecentProducts(10);
        ObservableList<ProductSummary> rows = FXCollections.observableArrayList(list);
        if (tblRecentProducts != null) tblRecentProducts.setItems(rows);
    }
}
