package com.papantsh.onlineshop.ui;

/**
 * Deprecated stub. Confirmation dialogs are now implemented using styled JavaFX Alerts.
 */
public final class ConfirmationDialogController {
    private ConfirmationDialogController() {}
}
