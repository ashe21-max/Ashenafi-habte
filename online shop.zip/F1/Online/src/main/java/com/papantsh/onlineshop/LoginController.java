package com.papantsh.onlineshop;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Dialog;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ButtonBar;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label statusLabel;

    @FXML
    private void onLoginClick() {
        try {
            if (usernameField == null || passwordField == null) {
                if (statusLabel != null) statusLabel.setText("Login fields not initialized.");
                return;
            }
            String username = usernameField.getText() == null ? "" : usernameField.getText().trim();
            String password = passwordField.getText() == null ? "" : passwordField.getText().trim();

            if (username.isEmpty() || password.isEmpty()) {
                statusLabel.setText("Please fill all fields.");
                return;
            }

            User userCheck = DBHandler.getUserByUsername(username);
            if (userCheck == null) {
                statusLabel.setText("Invalid username or password.");
                return;
            }
            if (!userCheck.isActive()) {
                statusLabel.setText("Account is disabled. Contact admin.");
                return;
            }

            boolean loginSuccess;
            try {
                loginSuccess = DBHandler.validateLogin(username, password);
            } catch (Exception ex) {
                ex.printStackTrace();
                statusLabel.setText("Login error: " + ex.getMessage());
                return;
            }
            System.out.println("Login attempt for user='" + username + "' -> success? " + loginSuccess);

            if (loginSuccess) {
                User user = DBHandler.getUserByUsername(username);
                if (user != null) {
                    CurrentSession.setUser(user.getId(), user.getUsername());
                    CurrentSession.setRole(user.getRole());
                }

                statusLabel.setText("");

                SceneController sc = new SceneController(Main.mainStage);
                try {
                    if (CurrentSession.getRole() != null && CurrentSession.getRole().equalsIgnoreCase("ADMIN")) {
                        sc.switchTo("admin_dashboard.fxml");
                    } else {
                        sc.switchTo("dashboard.fxml");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    statusLabel.setText("Navigation error: " + ex.getMessage());
                }

            } else {
                statusLabel.setText("Invalid username or password.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (statusLabel != null) statusLabel.setText("Unexpected error: " + e.getMessage());
        }
    }

    @FXML
    private void onForgotPassword() {
        Dialog<java.util.Map<String,String>> dlg = new Dialog<>();
        dlg.setTitle("Reset Password");
        ButtonType ok = new ButtonType("Reset", ButtonBar.ButtonData.OK_DONE);
        dlg.getDialogPane().getButtonTypes().addAll(ok, ButtonType.CANCEL);

        javafx.scene.layout.GridPane grid = new javafx.scene.layout.GridPane();
        grid.setHgap(10); grid.setVgap(10);
        TextField userField = new TextField(); userField.setPromptText("username");
        PasswordField newPass = new PasswordField(); newPass.setPromptText("new password");
        PasswordField confirm = new PasswordField(); confirm.setPromptText("confirm password");
        grid.add(new javafx.scene.control.Label("Username:"), 0, 0); grid.add(userField, 1, 0);
        grid.add(new javafx.scene.control.Label("New password:"), 0, 1); grid.add(newPass, 1, 1);
        grid.add(new javafx.scene.control.Label("Confirm:"), 0, 2); grid.add(confirm, 1, 2);
        dlg.getDialogPane().setContent(grid);

        dlg.setResultConverter(bt -> {
            if (bt == ok) {
                java.util.Map<String,String> m = new java.util.HashMap<>();
                m.put("username", userField.getText());
                m.put("pass", newPass.getText());
                m.put("confirm", confirm.getText());
                return m;
            }
            return null;
        });

        java.util.Optional<java.util.Map<String,String>> res = dlg.showAndWait();
        if (res.isPresent()) {
            java.util.Map<String,String> m = res.get();
            String u = m.get("username");
            String p = m.get("pass");
            String c = m.get("confirm");
            if (u == null || u.isBlank() || p == null || p.isBlank()) {
                statusLabel.setText("Username and password required.");
                return;
            }
            if (!p.equals(c)) {
                statusLabel.setText("Passwords do not match.");
                return;
            }

            User uobj = DBHandler.getUserByUsername(u);
            if (uobj == null) {
                statusLabel.setText("User not found.");
                return;
            }

            String sql = "UPDATE users SET password = ? WHERE username = ?";
            try (java.sql.Connection conn = DBHandler.connect(); java.sql.PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, DBHandler.hashPassword(p));
                ps.setString(2, u);
                ps.executeUpdate();
                statusLabel.setStyle("-fx-text-fill: green;");
                statusLabel.setText("Password reset successfully.");
            } catch (java.sql.SQLException ex) {
                statusLabel.setText("Error: " + ex.getMessage());
            }
        }
    }

    @FXML
    private void onRegisterClick() {
        SceneController sc = new SceneController(Main.mainStage);
        sc.switchTo("register.fxml");
    }

}
