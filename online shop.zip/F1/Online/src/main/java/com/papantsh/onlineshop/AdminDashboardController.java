package com.papantsh.onlineshop;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

import com.papantsh.onlineshop.dao.StatsDao;
import com.papantsh.onlineshop.dao.StatsDaoImpl;
import com.papantsh.onlineshop.dao.OrderSummary;

import java.io.IOException;

public class AdminDashboardController {

    @FXML private Button btnProducts;
    @FXML private Button btnRecentProducts;
    @FXML private Button btnAdminHome;
    @FXML private Button btnOrders;
    @FXML private Button btnCategories;
    @FXML private Button btnUsers;
    @FXML private Button btnSettings;
    @FXML private Button btnLogout;
    @FXML private StackPane centerPane;
    @FXML private Label lblWelcome;
    @FXML private Label lblTotalProducts;
    @FXML private Label lblTotalOrders;
    @FXML private Label lblPendingOrders;
    @FXML private Label lblTotalUsers;
    @FXML private TableView<OrderSummary> tblRecentOrders;
    @FXML private TableColumn<OrderSummary, Integer> colOrderId;
    @FXML private TableColumn<OrderSummary, String> colOrderUser;
    @FXML private TableColumn<OrderSummary, String> colOrderDate;
    @FXML private TableColumn<OrderSummary, Double> colOrderTotal;
    @FXML private TableColumn<OrderSummary, String> colOrderStatus;

    @FXML
    private void initialize() {
        // protect admin area
        if (CurrentSession.getRole() == null || !CurrentSession.getRole().equalsIgnoreCase("ADMIN")) {
            // not authorized - send back to login
            CurrentSession.clear();
            SceneController sc = new SceneController(Main.mainStage);
            sc.switchTo("login.fxml");
            return;
        }

        // display user + role in topbar and welcome
        javafx.scene.layout.HBox topbarBox = null;
        try {
            topbarBox = (javafx.scene.layout.HBox) ((javafx.scene.Parent) centerPane.getScene().getRoot()).lookup("#topbar");
        } catch (Exception ex) {
            // fallback: try to lookup from the scene
            try {
                topbarBox = (javafx.scene.layout.HBox) centerPane.getScene().lookup("#topbar");
            } catch (Exception ignore) {}
        }

        if (CurrentSession.getUsername() != null && lblWelcome != null) {
            lblWelcome.setText("Welcome Admin: " + CurrentSession.getUsername() + " (" + CurrentSession.getRole() + ")");
        }

        // Initialize stats using StatsDao
        StatsDao stats = new StatsDaoImpl();
        try {
            if (lblTotalProducts != null) lblTotalProducts.setText(String.valueOf(stats.getTotalProducts()));
            if (lblTotalOrders != null) lblTotalOrders.setText(String.valueOf(stats.getTotalOrders()));
            if (lblPendingOrders != null) lblPendingOrders.setText(String.valueOf(stats.getPendingOrders()));
            if (lblTotalUsers != null) lblTotalUsers.setText(String.valueOf(stats.getTotalUsers()));

            // configure table columns
            if (colOrderId != null) colOrderId.setCellValueFactory(new PropertyValueFactory<>("id"));
            if (colOrderUser != null) colOrderUser.setCellValueFactory(new PropertyValueFactory<>("username"));
            if (colOrderDate != null) colOrderDate.setCellValueFactory(new PropertyValueFactory<>("orderDate"));
            if (colOrderTotal != null) colOrderTotal.setCellValueFactory(new PropertyValueFactory<>("total"));
            if (colOrderStatus != null) colOrderStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

            if (tblRecentOrders != null) {
                ObservableList<OrderSummary> rows = FXCollections.observableArrayList(stats.getRecentOrders(5));
                tblRecentOrders.setItems(rows);
            }
        } catch (Exception ex) {
            System.out.println("Error initializing admin stats: " + ex.getMessage());
        }

        if (topbarBox != null) {
            Label lblUserInfo = (Label) topbarBox.lookup("#lblUserInfo");
            if (lblUserInfo != null) {
                lblUserInfo.setText(CurrentSession.getUsername() + " (" + CurrentSession.getRole() + ")");
            }
            // wire profile button on topbar and avatar
            try {
                javafx.scene.control.Button btnProfile = (javafx.scene.control.Button) topbarBox.lookup("#btnProfile");
                if (btnProfile != null) btnProfile.setOnAction(e -> loadPage("admin_settings.fxml"));
                javafx.scene.image.ImageView avatar = (javafx.scene.image.ImageView) topbarBox.lookup("#imgAvatar");
                if (avatar != null) {
                    try {
                        User u = DBHandler.getUserByUsername(CurrentSession.getUsername());
                        if (u != null && u.getImagePath() != null && !u.getImagePath().isBlank()) {
                            avatar.setImage(new javafx.scene.image.Image(new java.io.File(u.getImagePath()).toURI().toString()));
                        }
                    } catch (Exception ignore) {}
                }
            } catch (Exception ignore) {}
        }

        btnProducts.setOnAction(e -> loadPage("admin_products.fxml"));
        btnRecentProducts.setOnAction(e -> loadPage("admin_recent_products.fxml"));
        btnOrders.setOnAction(e -> loadPage("admin_orders.fxml"));
        btnCategories.setOnAction(e -> loadPage("admin_categories.fxml"));
        btnUsers.setOnAction(e -> loadPage("admin_users.fxml"));
        btnSettings.setOnAction(e -> loadPage("admin_settings.fxml"));

        // restore overview content when Dashboard clicked
        try {
            if (btnAdminHome != null) {
                final javafx.scene.Node original = centerPane.getChildren().isEmpty() ? null : centerPane.getChildren().get(0);
                btnAdminHome.setOnAction(e -> {
                    if (original != null) {
                        centerPane.getChildren().clear();
                        centerPane.getChildren().add(original);
                    }
                });
            }
        } catch (Exception ex) {
            System.out.println("Could not wire admin home button: " + ex.getMessage());
        }

        btnLogout.setOnAction(e -> {
            boolean confirm = com.papantsh.onlineshop.ui.DialogUtil.confirmBlocking("Logout", "Are you sure you want to logout?");
            if (confirm) {
                // clear session and go back to login
                CurrentSession.clear();
                SceneController sc = new SceneController(Main.mainStage);
                sc.switchTo("login.fxml");
            }
        });
    }

    private void loadPage(String fxmlFile) {
        try {
            // Load FXML and set to centerPane
            Parent page = FXMLLoader.load(getClass().getResource("/fxml/" + fxmlFile));
            centerPane.getChildren().clear();
            centerPane.getChildren().add(page);
            // log the navigation and show a subtle notification
            com.papantsh.onlineshop.LogUtil.log("INFO", "Admin opened page: " + fxmlFile + " by user=" + CurrentSession.getUsername());
            try { com.papantsh.onlineshop.ui.NotificationUtil.showInfo("Opened " + fxmlFile); } catch (Exception ignore) {}
        } catch (IOException ex) {
            ex.printStackTrace();
            com.papantsh.onlineshop.LogUtil.log("ERROR", "Failed to load page " + fxmlFile + ": " + ex.getMessage());
            try { javafx.application.Platform.runLater(() -> com.papantsh.onlineshop.ui.NotificationUtil.showError("Unable to load: " + fxmlFile)); } catch (Exception ignore) {}
        } catch (RuntimeException rex) {
            // catch unforeseen runtime issues during loading / initialize
            rex.printStackTrace();
            com.papantsh.onlineshop.LogUtil.log("ERROR", "Runtime error while loading page " + fxmlFile + ": " + rex.getMessage());
            try { javafx.application.Platform.runLater(() -> com.papantsh.onlineshop.ui.NotificationUtil.showError("Failed to open: " + fxmlFile)); } catch (Exception ignore) {}
        }
    }
}
