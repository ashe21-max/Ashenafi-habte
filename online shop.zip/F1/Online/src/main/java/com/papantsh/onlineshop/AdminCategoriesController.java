package com.papantsh.onlineshop;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import com.papantsh.onlineshop.dao.CategoryDao;
import com.papantsh.onlineshop.dao.CategoryDaoImpl;
import com.papantsh.onlineshop.dao.Category;

import java.util.List;

public class AdminCategoriesController {

    @FXML private TextField txtCategoryName;
    @FXML private Button btnAdd;
    @FXML private Button btnUpdate;
    @FXML private Button btnDelete;
    @FXML private TableView<Category> tblCategories;
    @FXML private TableColumn<Category, Integer> colCatId;
    @FXML private TableColumn<Category, String> colCatName;

    private CategoryDao dao = new CategoryDaoImpl();

    @FXML
    private void initialize() {
        if (colCatId != null) colCatId.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("id"));
        if (colCatName != null) colCatName.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("name"));

        refreshList();

        if (tblCategories != null) {
            tblCategories.getSelectionModel().selectedItemProperty().addListener((obs, oldv, newv) -> {
                if (newv != null) txtCategoryName.setText(newv.getName());
            });
        }

        if (btnAdd != null) btnAdd.setOnAction(e -> doAdd());
        if (btnUpdate != null) btnUpdate.setOnAction(e -> doUpdate());
        if (btnDelete != null) btnDelete.setOnAction(e -> doDelete());
    }

    private void refreshList() {
        List<Category> list = dao.findAll();
        ObservableList<Category> rows = FXCollections.observableArrayList(list);
        if (tblCategories != null) tblCategories.setItems(rows);
    }

    private void doAdd() {
        String name = txtCategoryName.getText();
        if (name == null || name.isBlank()) return;
        boolean ok = dao.create(name.trim());
        if (ok) {
            txtCategoryName.clear();
            refreshList();
        } else {
            showAlert("Could not add category. It may already exist.");
        }
    }

    private void doUpdate() {
        Category sel = tblCategories.getSelectionModel().getSelectedItem();
        if (sel == null) return;
        String name = txtCategoryName.getText();
        if (name == null || name.isBlank()) return;
        boolean ok = dao.update(sel.getId(), name.trim());
        if (ok) refreshList(); else showAlert("Update failed");
    }

    private void doDelete() {
        Category sel = tblCategories.getSelectionModel().getSelectedItem();
        if (sel == null) return;
        if (com.papantsh.onlineshop.ui.DialogUtil.confirm("Delete category", "Delete category '" + sel.getName() + "'?")) {
            boolean ok = dao.delete(sel.getId());
            if (ok) refreshList(); else showAlert("Delete failed");
        }
    }

    private void showAlert(String msg) {
        com.papantsh.onlineshop.ui.DialogUtil.showError(msg);
    }
}
