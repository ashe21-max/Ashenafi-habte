package com.papantsh.onlineshop.dao;

import java.util.List;

public interface ProductRecentDao {
    List<ProductSummary> getRecentProducts(int limit);
}
