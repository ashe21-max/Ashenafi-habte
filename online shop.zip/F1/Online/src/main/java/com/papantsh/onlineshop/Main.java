package com.papantsh.onlineshop;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage; 

public class Main extends Application {
    public static Stage mainStage;

    @Override
    public void start(Stage stage) throws Exception {
        mainStage = stage;

        // Create DB tables
        DBHandler.createTables();

        Parent root = FXMLLoader.load(getClass().getResource("/fxml/login.fxml"));
        Scene scene = new Scene(root);
        // attach global stylesheet
        try {
            scene.getStylesheets().add(getClass().getResource("/css/styles.css").toExternalForm());
        } catch (Exception ignore) {}
        stage.setScene(scene);
        stage.setTitle("Online Shop");
        // start in a reasonable medium size (not maximized)
        try {
            stage.setWidth(1000);
            stage.setHeight(700);
            stage.centerOnScreen();
        } catch (Exception ignore) {}
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
