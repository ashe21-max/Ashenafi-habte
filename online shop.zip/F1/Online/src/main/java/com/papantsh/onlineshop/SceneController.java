package com.papantsh.onlineshop;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SceneController {

    private final Stage stage;

    public SceneController(Stage stage) {
        this.stage = stage;
    }

    public void switchTo(String fxml) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/" + fxml));
            stage.setScene(new Scene(root));
            stage.show();
            // no additional window control wiring required here (use system window controls)
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
