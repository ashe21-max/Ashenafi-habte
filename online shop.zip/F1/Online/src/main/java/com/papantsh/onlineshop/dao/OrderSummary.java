package com.papantsh.onlineshop.dao;

import java.time.LocalDateTime;

public class OrderSummary {
    private int id;
    private String username;
    private double total;
    private String status;
    private String orderDate; // store as ISO string for simplicity

    public OrderSummary(int id, String username, double total, String status, String orderDate) {
        this.id = id;
        this.username = username;
        this.total = total;
        this.status = status;
        this.orderDate = orderDate;
    }

    public int getId() { return id; }
    public String getUsername() { return username; }
    public double getTotal() { return total; }
    public String getStatus() { return status; }
    public String getOrderDate() { return orderDate; }
}
